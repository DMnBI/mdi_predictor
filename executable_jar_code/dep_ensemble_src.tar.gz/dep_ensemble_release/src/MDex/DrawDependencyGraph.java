package MDex;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import MDex.DependencyTree.DependencyTree;

public class DrawDependencyGraph {
	public DrawDependencyGraph() {}
	public static void main(String args[])
	{
		String input_path = "input/10-fold/fold8_test.txt";
		String output_dir = "output/dependency_graph/fold8/";
		DrawDependencyGraph ddg = new DrawDependencyGraph();
		ddg.read_input(input_path, output_dir);
	}
	private void read_input(String input_path, String output_dir)
	{
		try {
			String eachline;
			BufferedReader br = new BufferedReader
					(new FileReader(new File(input_path)));
			while((eachline = br.readLine()) != null)
			{
				System.out.println(eachline);
				String id = eachline.split("\t")[0];
				String corpus = eachline.split("\t")[2];
				System.out.println(id+", "+corpus);
				DependencyTree dt = new DependencyTree();
				dt.set(corpus, output_dir+"graph_"+id+".png");
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
