package MDex;

import MDex.DependencyTree.DependencyNode;
import MDex.DependencyTree.EntitySet;

public class Rule3 {
	
	public String run(EntitySet entity_set)
	{
		SubRelation subRelation = new SubRelation();
		DependencyNode node1, node2, lca;
		if(entity_set.bacteria.position > entity_set.disease.position)
		{
			node1 = entity_set.bacteria;
			node2 = entity_set.disease;
		}
		else
		{
			node1 = entity_set.disease;
			node2 = entity_set.bacteria;
		}
		lca = entity_set.lca;
		
		String relation_wNode1 = subRelation.find(lca, node1);
		String relation_wNode2 = subRelation.find(lca, node2);
		
		if(!relation_wNode1.equals(lca.word))
			return relation_wNode1;
		else
			return relation_wNode2;
	}
}
