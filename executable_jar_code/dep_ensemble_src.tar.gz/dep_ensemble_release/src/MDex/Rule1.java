package MDex;

import java.util.ArrayList;

import MDex.DependencyTree.DependencyNode;
import MDex.DependencyTree.EntitySet;
import utils.Pair;
import utils.Triplet;

public class Rule1 {

	public String run(EntitySet entity_set, ArrayList<Pair<Triplet, Integer>> prev_relations)
	{
		DependencyNode disease = entity_set.disease;
		DependencyNode bacteria = entity_set.bacteria;
		DependencyNode lca = entity_set.lca;
		
		String relation;
		
		relation = get_relation_between_ancestor_and_partner
				(disease, bacteria, lca, prev_relations);
		if(relation == null)
			relation = get_relation_between_ancestor_and_partner
			(bacteria, disease, lca, prev_relations);
		
		return relation;
	}
	
	private String get_relation_between_ancestor_and_partner(DependencyNode node, DependencyNode partner,
			DependencyNode lca, ArrayList<Pair<Triplet, Integer>> prev_relations)
	{
		for(DependencyNode ancestor = node
				; !ancestor.word.equals("ROOT") && !ancestor.equals(lca.parent)
				; ancestor = ancestor.parent)
		{
			if(ancestor.edge_with_parent.startsWith("parataxis"))
				return null;
			if(node.tag == ancestor.tag)
			{				
				for(Pair<Triplet, Integer> relation : prev_relations)
				{
					Triplet triplet = relation.getFirst();
					if((triplet.entity1.equals(ancestor.get_only_entity()) && triplet.entity1_position == ancestor.position
							&& triplet.entity2.equals(partner.get_only_entity()) && triplet.entity2_position == partner.position))
						return triplet.relation;
					else if((triplet.entity2.equals(ancestor.get_only_entity()) && triplet.entity2_position == ancestor.position
							&& triplet.entity1.equals(partner.get_only_entity()) && triplet.entity1_position == partner.position))
						return triplet.relation;
				}
			}
		}
		return null;
	}
	
	

}
