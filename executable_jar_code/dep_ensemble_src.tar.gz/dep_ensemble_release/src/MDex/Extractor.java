package MDex;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import MDex.DependencyTree.DependencyNode;
import MDex.DependencyTree.DependencyTree;
import MDex.DependencyTree.EntitySet;
import utils.Stemmer;
import utils.Pair;
import utils.Triplet;

public class Extractor {
	
	private static final int _DISTANCE_THRESHOLD = 5;
	
	private Stemmer stemmer;
	
	public Extractor()
	{
		stemmer = new Stemmer();
	}
	
	public ArrayList<Pair<Triplet, Integer>> extract(String sentence, String graph_path)
	{		
		Rule rule = new Rule();
		
		ArrayList<Pair<Triplet, Integer>> relation_list = new ArrayList<Pair<Triplet, Integer>>();
		DependencyTree dependency_tree = new DependencyTree();
		dependency_tree.set(sentence, graph_path);
		dependency_tree.set_entity_pairs();
		
		Pair<String, Integer> extracted_relation;
		
		for(EntitySet entity_set : dependency_tree.entity_set_list)
		{
			
			String relation_word = null;
			int used_rule = 0;
			if(entity_set.lca == null || entity_set.distance >= _DISTANCE_THRESHOLD)
				continue;
			else
			{
				extracted_relation = rule.run(sentence, entity_set, relation_list);
				if(extracted_relation.getFirst() != null)
				{
					Pair<Triplet, Integer> new_pair = create_triplet_pair(dependency_tree.tag_list,
							entity_set, extracted_relation);
					if(new_pair != null)
						relation_list.add(new_pair);
				}
			}			
		}
		
		return relation_list;
	}
	
	private Pair<Triplet, Integer> create_triplet_pair(HashMap<String, String> tag_list
			, EntitySet entity_set, Pair<String, Integer> extracted_relation)
	{
		DependencyNode bacteria = entity_set.bacteria;
		DependencyNode disease = entity_set.disease;
		
		String relation_word = extracted_relation.getFirst();
		int used_rule = extracted_relation.getSecond();
		
		for(String key : tag_list.keySet()) //relation이 entity일 경우 제외시킴
		{
			String tag = tag_list.get(key);
			if(relation_word.contains(tag)) 
				return null;
		}
		
		if(Pattern.matches("[\\W\\d_]+", relation_word) || relation_word.length() <= 1)//relation word is not word
			return null;
		
		
		//create pair of triplet
		Triplet new_triplet = new Triplet(bacteria.get_only_entity(), bacteria.position
				, disease.get_only_entity(), disease.position, stemmer.getStem(relation_word));
		
		return new Pair<Triplet, Integer>(new_triplet, used_rule);
	}
	

}
