package MDex;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import MDex.DependencyTree.EntitySet;

public class Rule2 {
	
	private ArrayList<String> rule2_relation;
	
	static String regex = "(%s|%s)\\s+"
			+ "(by|in|from|on|with|of|due to|induced)"
			+ "\\s+(%s|%s)";
		
	public String run(String sentence, EntitySet entity_set)
	{
		String entity1 = entity_set.bacteria.word;
		String entity2 = entity_set.disease.word;
		
		String subStr = getSubStr(sentence
				, entity_set.bacteria.position
				, entity_set.disease.position);
//		System.out.println("substring!: "+subStr);
		
		String entity_regex = String.format(regex, entity1, entity2
				, entity1, entity2);
		return findRegex(subStr, entity_regex);
		
	}
	public String findRegex(String sentence, String regex)
	{
		Pattern pattern;
		Matcher matcher;
		
		pattern = Pattern.compile(regex);
		matcher = pattern.matcher(sentence);
		if(matcher.find())
		{
			String tmp_entity1, tmp_entity2, relation;
			
			String[] relation_paragraph = matcher.group().split("\\s+");
			tmp_entity1 = relation_paragraph[0];
			tmp_entity2 = relation_paragraph[relation_paragraph.length-1];
			relation = relation_paragraph[1];
			
			if(!tmp_entity1.equals(tmp_entity2))
				return relation;
		}
		return null;
	}
	private String getSubStr(String sentence
			, int position1, int position2)
	{
		int start, end;
		if(position1 < position2)
		{
			start = position1;
			end = position2;
		}
		else
		{
			start = position2;
			end = position1;
		}
		String[] split_sent = sentence.split("\\s+");
		String subWord = "";
		for(;start <= end; start++)
		{
			subWord+=" "+split_sent[start-1];
		}
		return subWord.trim();
	}
}
