package MDex;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Main.Configure;
import utils.Pair;
import utils.Triplet;

public class MDex {
	
	public static Dictionary same_level_edges;
	public static Dictionary sub_relation_list;
	
	private Extractor extractor;
	public MDex(Configure config)
	{
		same_level_edges 
			= new Dictionary(config.SAMELEVEL_RELATION_LIST_PATH);
		sub_relation_list
			= new Dictionary(config.SUB_RELATION_LIST_PATH);
		
		extractor = new Extractor();
	}
	
	public ArrayList<Pair<Triplet, Integer>> get_relation(String sentence, String graph_path)
	{
		sentence = chunk_apposition(sentence);		
		return extractor.extract(sentence, graph_path);
	}
	
	private String chunk_apposition(String sentence)
	{
		Pattern p = Pattern.compile("\\s+\\S+\\s+(of|with)\\s+(BAC00|DIS00)");
		Matcher match = p.matcher(sentence);
		
		while(match.find())
		{
			String chunk = match.group().substring(1);
			if(chunk.replaceAll("(of|with)\\s+(BAC00|DIS00)", "").trim().length() <= 1)
				continue;
			Matcher entities = Pattern.compile("(BAC|DIS)00").matcher(chunk);
			String tmp_chunk = chunk.replaceAll("(BAC|DIS)00", ""); //둘 이상의 entity를 포함할 경우(같은 타입 포함), 그대로 유지
			if((chunk.length()-tmp_chunk.length())/5 >= 2)
				continue;
			
			sentence = sentence.replace(chunk, chunk.replaceAll("\\s+", "_"));
		
		}
		return sentence;
	}
}
