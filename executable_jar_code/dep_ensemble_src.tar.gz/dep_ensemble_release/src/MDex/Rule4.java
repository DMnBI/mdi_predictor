package MDex;

import MDex.DependencyTree.DependencyNode;
import MDex.DependencyTree.EntitySet;

public class Rule4 {
	
	public String run(EntitySet entity_set)
	{
		String relation_word;
		DependencyNode ancestor, descendant;
		
		if(entity_set.bacteria.depth > entity_set.disease.depth)
		{
			ancestor = entity_set.disease;
			descendant = entity_set.bacteria;
		}
		else
		{
			ancestor = entity_set.bacteria;
			descendant = entity_set.disease;
		}
		
		if(descendant.parent.equals(ancestor)) //if they are directly connected
			relation_word = find_relation_from_direct_connection(ancestor, descendant);
		
		else //find relation from undirect connection
		{
			SubRelation sub_relation = new SubRelation();
			relation_word = sub_relation.find(ancestor, descendant);
		}
		
		return relation_word;
	}
	
	private String find_relation_from_direct_connection(DependencyNode ancestor, DependencyNode descendant)
	{
		String relation = null;
		String edge = descendant.edge_with_parent;
		
		if(edge.startsWith("nmod:"))
		{
			edge = edge.split("nmod:")[1];
			if(edge.equals("due_to"))
				relation = "due";
			else if(!edge.equals("to"))
				relation = edge;
		}
		else if(edge.contains("conj:and"))
		{
			if(ancestor.edge_with_parent.equals("nmod:between"))
				relation = ancestor.parent.word;
			else
				relation = null;
		}
		else
		{
			relation = descendant.word; // child -> parent 순
			if(relation.startsWith("DIS00") || relation.startsWith("BAC00"))
				relation = ancestor.word;
//			System.out.println(relation);
		}
		return relation;
	}
	

}
