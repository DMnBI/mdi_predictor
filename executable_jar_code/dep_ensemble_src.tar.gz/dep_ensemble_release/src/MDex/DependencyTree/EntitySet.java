package MDex.DependencyTree;

import MDex.MDex;

public class EntitySet {
	
	public DependencyNode bacteria;
	public DependencyNode disease;
	public DependencyNode lca;
	
	public int distance;
	
	public EntitySet(DependencyNode bacteria, DependencyNode disease)
	{
		this.bacteria = bacteria;
		this.disease = disease;
		this.lca = null;
		
		find_LCA();
		set_distance();
	}
	public void find_LCA()
	{
		boolean is_parataxis;
		
		DependencyNode bacteria_ancestor, disease_ancestor;
		for(bacteria_ancestor = this.bacteria
				; bacteria_ancestor.parent != null
				; bacteria_ancestor = bacteria_ancestor.parent)
		{
			if(bacteria_ancestor.edge_with_parent.contains("parataxis")) 
				// ���� ���� �� ������ �մ� ������ ���, �� Ʈ���� ���������� ���� LCA�� ���ٰ� �Ǵ��Ѵ�.
				return;
			
			is_parataxis = false;
			for(disease_ancestor = this.disease
					; disease_ancestor.parent != null 
					; disease_ancestor = disease_ancestor.parent)
			{
				if(bacteria_ancestor.equals(disease_ancestor))
				{
					if(!is_parataxis)
						lca = bacteria_ancestor;						
					return;
				}
				else if(disease_ancestor.edge_with_parent.contains("parataxis"))
					is_parataxis = true;
			}
		}
	}
	
	public void set_distance()
	{
		if(lca != null) {
			distance = get_distance(bacteria, lca) + get_distance(disease, lca);
		}
		else if(bacteria.depth > disease.depth)
			distance = get_distance(bacteria, disease);
		else
			distance = get_distance(disease, bacteria);
		
	}
	
	public int get_distance(DependencyNode descendant, DependencyNode ancestor)
	{
		int distance = 0;
		while(!descendant.equals(ancestor) && descendant.parent != null)
		{
			if(MDex.same_level_edges.contains(descendant.edge_with_parent)) {}
			else
				distance++;
			descendant = descendant.parent;
		}
		return distance;
	}
}
 