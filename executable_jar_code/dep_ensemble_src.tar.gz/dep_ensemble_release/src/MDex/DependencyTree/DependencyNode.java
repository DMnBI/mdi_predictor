package MDex.DependencyTree;

import java.util.ArrayList;

public class DependencyNode {
	
	public String word;
	public String edge_with_parent;
	public String tag;
	public int position;
	public String pos;
	public boolean is_visit;
	public int depth;
	
	public DependencyNode parent;
	public ArrayList<DependencyNode> children;
	
	public DependencyNode()
	{
		parent = null;
		children = new ArrayList<>();
		is_visit = false;
	}
	public boolean is_entity()
	{
		if(word.contains("BAC00"))
			return true;
		else if(word.contains("DIS00"))
			return true;
		return false;
	}
	public String get_only_entity()
	{
		String str = word;
		String[] splited_str = str.split("(of|with)_(?i)(bac00|dis00)");
		if(splited_str.length <= 1)
			return str;
		else if(str.toLowerCase().contains("bac00"))
		{
			return "BAC00"+splited_str[splited_str.length-1];
		}
		else if(str.toLowerCase().contains("dis00"))
		{
			return "DIS00"+splited_str[splited_str.length-1];
		}
		
		return str; 
	}
}
