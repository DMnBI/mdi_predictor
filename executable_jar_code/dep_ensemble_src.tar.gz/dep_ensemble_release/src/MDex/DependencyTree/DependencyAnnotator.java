package MDex.DependencyTree;

import java.util.Properties;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;

public class DependencyAnnotator {

	public static StanfordCoreNLP pipeline()
	{
		Properties props = new Properties();
		props.setProperty("annotators", "tokenize,ssplit,pos,lemma,ner,depparse,natlog");
		props.put("tokenize.whitespace", "true");
	    StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
	    
	    return pipeline;
	}
}
