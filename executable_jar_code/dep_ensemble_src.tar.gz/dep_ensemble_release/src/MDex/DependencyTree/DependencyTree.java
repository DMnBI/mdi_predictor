package MDex.DependencyTree;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreAnnotations.PartOfSpeechAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.semgraph.SemanticGraph;
import edu.stanford.nlp.semgraph.SemanticGraphCoreAnnotations.CollapsedDependenciesAnnotation;
import edu.stanford.nlp.util.CoreMap;

public class DependencyTree {

	
	public HashMap<String, String> tag_list;
	
	public StanfordCoreNLP pipeline;
	
	public String sentence;
	public List<CoreLabel> token_list;
	
	public HashMap<String, DependencyNode> node_list;
	public ArrayList<EntitySet> entity_set_list;
	
	private HashMap<String, String> compound_set = new HashMap<>();
	
	public DependencyNode root;
	
	public DependencyTree()
	{
		tag_list = new HashMap<String, String>();
		tag_list.put("bacteria", "BAC00");
		tag_list.put("disease", "DIS00");
		tag_list.put("drug", "DRG00");		
		
		node_list = new HashMap();
		entity_set_list = new ArrayList<EntitySet>();
	}
	
	public void set(String corpus, String graph_path)
	{
		Annotation doc;
		List<CoreLabel> token_list;
		CoreMap annotated_sentence;
				
		doc = new Annotation(corpus);
		setPipeline(doc);
		
		this.token_list = doc.get(CoreAnnotations.TokensAnnotation.class);
		annotated_sentence = doc.get(SentencesAnnotation.class).get(0);
		
		this.sentence = annotated_sentence.toString();
		
		build_dependency_tree(annotated_sentence, graph_path);
	}
	
	public void build_dependency_tree(CoreMap annotated_sentence, String graph_path)
	{
		SemanticGraph dependency_graph 
			= annotated_sentence.get(CollapsedDependenciesAnnotation.class);
		String edge = dependency_graph.toList();
		/*
		 * edge_information example
		 * root(ROOT-0, was-6)
		 * det(aim-2, The-1)
		 * */
		
		if(graph_path != null)
			draw_graph(dependency_graph.toDotFormat(), graph_path);
		
		String[] edgeInfo_list = edge.split("\n");
		for(String edge_info : edgeInfo_list)
		{
			String pattern = "\\((\\S|\\s)+\\)";
			Pattern p = Pattern.compile(pattern);
			Matcher m = p.matcher(edge_info);
			String relation_tag = edge_info.split(pattern)[0];
			String[] node_info = {};
			m.find();
			node_info = get_node_information(m.group());
			
			add_nodes(node_info, relation_tag);
		}
		
		//find root node
		for(String key : node_list.keySet())
		{
			DependencyNode temp_node = node_list.get(key);
			if(temp_node.parent == null)
			{
				root = temp_node;
				break;						
			}
		}
		
		set_graph_depth(root, 0);
	}
	
	private void add_nodes(String[] node_information,
			String relation_tag)
	{
		DependencyNode parent_node, child_node;
		
		parent_node = create_node(node_information[0]);
		child_node = create_node(node_information[1]);
		
		if(parent_node.children.contains(child_node)
				|| parent_node.equals(child_node)) 
		{ 
		}
		else if(relation_tag.equals("compound"))
		{
			if(child_node.is_entity())
				parent_node.word = child_node.word;
			compound_set.put(node_information[1], node_information[0]);
			node_list.remove(node_information[1]);
		}
		else
		{
			parent_node.children.add(child_node);
			child_node.parent = parent_node;
			child_node.edge_with_parent = relation_tag;
		}		
	}
	
	private DependencyNode create_node(String node_info)
	{
		DependencyNode new_node;
		node_info = node_info.replaceAll("(\')+$", "");
		
		if(node_list.containsKey(node_info))
			new_node = node_list.get(node_info);
		else if(compound_set.containsKey(node_info))
			new_node = node_list.get(compound_set.get(node_info));
		else
		{
			new_node = new DependencyNode();
			String word = node_info.replaceAll("\\-[0-9]+$", "");
			String position = node_info.replaceAll("^\\S+\\-", "");
			
			new_node.word = word;
			new_node.position = Integer.parseInt(position);
			new_node.tag = get_tag(new_node.word);
			
			if(new_node.position > 0) //it is not root
			{
				new_node.pos = token_list.get(new_node.position-1)
						.getString(PartOfSpeechAnnotation.class);
			}
			node_list.put(node_info, new_node);
		}
		return new_node;
	}
	
	
	public String[] get_node_information(String edge_info)
	{
		String[] str = new String[2];
		edge_info = edge_info.substring(1, edge_info.length()-1);
		Pattern p = Pattern.compile("\\S+\\-[0-9]+");
		Matcher m = p.matcher(edge_info);
		
		m.find();
		str[0] = m.group();
		m.find();
		str[1] = m.group();
		
		return str;
	}
	
	public void set_entity_pairs()
	{
		ArrayList<DependencyNode> bacteria_entity_list = new ArrayList<DependencyNode>();
		ArrayList<DependencyNode> disease_entity_list = new ArrayList<DependencyNode>();
		
		bacteria_entity_list = get_entities(tag_list.get("bacteria"));
		disease_entity_list = get_entities(tag_list.get("disease"));
		
		HashMap<Double, EntitySet> entity_set = new HashMap<>();
		double index = 0.1;
		for(DependencyNode bacteria : bacteria_entity_list)
			for(DependencyNode disease : disease_entity_list)
			{
				entity_set.put(Math.abs(bacteria.position-disease.position)+index, new EntitySet(bacteria, disease));
				index += 0.1;
			}
		TreeMap<Double, EntitySet> tm = new TreeMap<Double, EntitySet>(entity_set);
		Iterator<Double> iteratorKey = tm.keySet( ).iterator( );
		
		while(iteratorKey.hasNext()) {
			  Double key = iteratorKey.next();
//			  System.out.println(key);
			  entity_set_list.add(tm.get(key));
		}
	}
	
	public ArrayList<DependencyNode> get_entities(String entity_tag)
	{
		ArrayList<DependencyNode> entity_list = new ArrayList<DependencyNode>();
		for(String key : node_list.keySet())
		{
			DependencyNode temp_node = node_list.get(key);
			if(temp_node.word.contains(entity_tag))
				entity_list.add(temp_node);
		}
		return entity_list;
	}
	
	public void set_graph_depth(DependencyNode node, int depth)
	{
		node.depth = depth;
		for(DependencyNode child : node.children)
			set_graph_depth(child, depth+1);
	}
	
	private String get_tag(String str)
	{
		for(String key : tag_list.keySet())
		{
			if(str.contains(tag_list.get(key)))
				return tag_list.get(key);
		}
		return "None";
	}
	
	public void draw_graph(String dot, String graph_path){
		if(graph_path == null)
			return;
		GraphViz gv = new GraphViz();
		String type = "png";
		String representationType = "dot";
		
		String dir = graph_path;
		
		gv.writeGraphToFile(gv.getGraph(dot, type, representationType), dir);
	}
	
	public void setPipeline(Annotation doc)
	{
		pipeline = new DependencyAnnotator().pipeline();
		pipeline.annotate(doc);
	}
}
