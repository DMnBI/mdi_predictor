package MDex;

import java.util.ArrayList;

import MDex.DependencyTree.DependencyNode;
import MDex.DependencyTree.EntitySet;
import utils.Pair;
import utils.Triplet;

public class Rule {

	private static final int _RULE1 = 40;
	private static final int _RULE2 = 41;
	private static final int _RULE3 = 42;
	private static final int _RULE4 = 43;

	public Rule1 rule1;
	public Rule2 rule2;
	public Rule3 rule3;
	public Rule4 rule4;
	
	public Rule()
	{
		rule1 = new Rule1();
		rule2 = new Rule2();
		rule3 = new Rule3();
		rule4 = new Rule4();		
	}
	
	public Pair<String, Integer> run(String sentence, EntitySet entity_set, ArrayList<Pair<Triplet, Integer>> prev_relation_list)
	{
		String relation_word;
		int used_rule;
		
		DependencyNode disease = entity_set.disease;
		DependencyNode bacteria = entity_set.bacteria;
		DependencyNode lca = entity_set.lca;
		
//		System.out.println(">>"+disease.word+"-"+bacteria.word+"-"+lca.word);
		if((relation_word = rule1.run(entity_set, prev_relation_list)) != null)
			used_rule = _RULE1;
		else if((relation_word = rule2.run(sentence, entity_set)) != null)
			used_rule = _RULE2;
		else if(lca.equals(bacteria) || lca.equals(disease))
		{
			relation_word = rule4.run(entity_set);
			used_rule = _RULE4;
		}
		else
		{
			relation_word = rule3.run(entity_set);
			used_rule = _RULE3;
		}
		return new Pair(get_only_chunk(relation_word), used_rule);
	}

	public String get_only_chunk(String node_word)
	{	
		if(node_word == null)
			return null;
		
		String[] split_word = node_word.split("_(with|of)_(?i)(bac|dis)00");
		if(split_word.length > 1)
			return split_word[0];
		else
			return node_word;
	}
}
