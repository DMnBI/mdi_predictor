package MDex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Pattern;

import MDex.DependencyTree.DependencyNode;
import utils.Stemmer;

public class SubRelation {

	Dictionary subRel_dict;
	Stemmer stemmer;
	
	public SubRelation() 
	{
		subRel_dict = MDex.sub_relation_list;
		stemmer = new Stemmer();
	}
	
	public String find(DependencyNode relation, DependencyNode entity)
	{
		String relation_word;
		
		int index;
		ArrayList<DependencyNode> descendants_of_relation 
			= get_descendant_list(relation, entity);
								
		for(index = 0, relation_word = relation.word
				; index < descendants_of_relation.size() ; index ++)
		{
			DependencyNode descendant = descendants_of_relation.get(index);
//			System.out.println("descendant: "+descendant.word);
			if(stemmer.getStem(descendant.word).equals("be")
					|| descendant.pos.equals("DT")) // be verb or a/an
				continue;
			
			String tmp_sRelation = get_sub_relation(descendant);
//			System.out.println(tmp_sRelation+", "+descendant.edge_with_parent);
			if(tmp_sRelation == null)
				break;
			else 
				relation_word = tmp_sRelation;
		}
//		System.out.println("final relation: "+relation_word);
		return relation_word;
	}
	
	private String get_sub_relation(DependencyNode descendant)
	{
		//case: one of
		if(descendant.parent.word.equals("one") 
				&& descendant.edge_with_parent.equals("nmod:of"))
			return descendant.word;

		//case: belong to
		if(descendant.parent.word.equals("belong") 
				&& descendant.edge_with_parent.equals("nmod:to"))
			return descendant.word;
		
		//case: against
		if(descendant.edge_with_parent.equals("nmod:against"))
			return "against";
		
		//case: contain list of sub-relation
		if(subRel_dict.contains(descendant.edge_with_parent))
			return descendant.word;
		
		return null;
	}
	
	private ArrayList<DependencyNode> get_descendant_list(DependencyNode lca, DependencyNode node)
	{
		ArrayList<DependencyNode> descendant_list = new ArrayList<DependencyNode>();
		
		while(!node.equals(lca)) 
		{
			descendant_list.add(node);
			node = node.parent;
		}
		Collections.reverse(descendant_list);
		return descendant_list;
	}	
}
