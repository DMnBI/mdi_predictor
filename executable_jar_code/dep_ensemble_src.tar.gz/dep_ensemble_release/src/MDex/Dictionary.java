package MDex;

import java.io.File;
import java.util.HashSet;
import java.util.Scanner;

public class Dictionary extends HashSet<String>{
	public Dictionary(String dicFile)
	{
		read(dicFile);
	}	
	public void read(String dicFile)
	{
		try {
			Scanner sc = new Scanner(new File(dicFile));
			int cnt = 0;
			while (sc.hasNext()) {
				this.add(sc.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Dependency Relation Input Error");
		}
	}
	public boolean contains(String str)
	{	
		for(String edge : this)
		{
			if(str.contains(edge))
			{
				return true;
			}
		}
		return false;
	}
}
