package utils;

public class Triplet {

	public String entity1;
	public int entity1_position;
	public String entity2;
	public int entity2_position;
	public String relation;
	
	public Triplet(String entity1, String entity2, String relation)
	{
		this.entity1 = entity1;
		this.entity2 = entity2;
		this.relation = relation;
	}
	
	public Triplet(String entity1, int entity1_position, String entity2
			, int entity2_position, String relation)
	{
		this.entity1 = entity1;
		this.entity1_position = entity1_position;
		this.entity2 = entity2;
		this.entity2_position = entity2_position;
		this.relation = relation;
	}
	
}
