package utils;

import edu.stanford.nlp.process.Morphology;

public class Stemmer {


	private static Morphology stemmer;
	public Stemmer()
	{
		stemmer = new Morphology();
	}
	public static String getStem(String word)
	{	
		if(word.toLowerCase().contains("bac00") || word.toLowerCase().contains("dis00"))
			return "None";
		
		String stemmedWord = "";
		String[] tokenList = word.split("_");
		for(int i = 0 ; i < tokenList.length ; i ++)
		{		
			String token = tokenList[i];
			if(i == tokenList.length-1) {
				token = stemmer.stem(token);
			}
			stemmedWord = stemmedWord + " " + token;
		}
		stemmedWord = stemmedWord.trim();
		stemmedWord = stemmedWord.replaceAll("\\s", "_");

		return stemmedWord.trim(); 
	}
}
