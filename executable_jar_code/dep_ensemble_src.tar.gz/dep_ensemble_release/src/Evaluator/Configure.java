package Evaluator;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Configure {
    public String GROUND_TRUTH_PATH;
    public String PREDICTION_PATH;
    
    public boolean USE_SVM_FILTER;
    
    public String SVM_FILTER_DIR;
    public Double SVM_FILTER_THRESHOLD;
    public String CONFIDENCE_PATH;
    public Double CONFIDENCE_THRESHOLD;

    public Configure(String configPath) {
        // READ OPTIONS (ARGUMENTS)
        Properties options = new Properties();
        InputStream input;
        try {
            input = new FileInputStream(configPath);
            options.load(input);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        // DISPLAY OPTIONS & HYPER-PARAMETERS
        this.GROUND_TRUTH_PATH = options.getProperty("GROUND_TRUTH_PATH");
        this.PREDICTION_PATH = options.getProperty("PREDICTION_PATH");
        this.USE_SVM_FILTER = Boolean.getBoolean(options.getProperty("USE_SVM_FILTER"));
        this.SVM_FILTER_DIR = options.getProperty("SVM_FILTER_DIR");
        this.SVM_FILTER_THRESHOLD = Double.parseDouble(options.getProperty("SVM_FILTER_THRESHOLD"));
        this.CONFIDENCE_PATH = options.getProperty("CONFIDENCE_PATH");
        this.CONFIDENCE_THRESHOLD = Double.parseDouble(options.getProperty("CONFIDENCE_THRESHOLD"));

        System.out.println("INPUT_DATA_PATH = " + this.GROUND_TRUTH_PATH);
        System.out.println("OUTPUT_RESULT_PATH = " + this.PREDICTION_PATH);
        System.out.println("USE_SVM_FILTER = " + this.USE_SVM_FILTER);
        System.out.println("SVM_FILTER_DIR = " + this.SVM_FILTER_DIR);
        System.out.println("SVM_FILTER_THRESHOLD = " + this.SVM_FILTER_THRESHOLD);
        System.out.println("CONFIDENCE_PATH = " + this.CONFIDENCE_PATH);
        System.out.println("CONFIDENCE_THRESHOLD = " + this.CONFIDENCE_THRESHOLD);
    }
}
