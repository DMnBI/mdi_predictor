package Evaluator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import Main.DataHelpers;
import utils.Pair;

public class Evaluator {
	
	BufferedWriter output_writer;
	
	public List<Pair<String, String>> get_truth(String path)
	{
		List<Pair<String, String>> label = new ArrayList<>();
		BufferedReader br;
		
		try {
			br = new BufferedReader(new FileReader(path));
			String each_line;
			while((each_line = br.readLine()) != null) 
			{
				//data[0] = index(integer)
				//data[1] = tagged_sentence(string)
				//data[2] = label_answer(string) (ex. DIS00AA&BAC00AA&cause,DIS00BB&BAC00BB&induce)
				String[] data = each_line.split("\t");
				label.add(new Pair<>(data[0], data[2]));
			}
			br.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
		return label;		
	}
	
	public List<Pair<String, String>> get_prediction(String path)
	{
		List<Pair<String, String>> label = new ArrayList<>();
		BufferedReader br;
		try {
            br = new BufferedReader(new FileReader(path));
            String curLine;
            while ((curLine = br.readLine()) != null) {
                // data[0] = index:integer
                // data[1] = (optional) label:string (ex. DIS00AA&BAC00AA&cause@0.6526,DIS00BB&BAC00BB&induce@0.9753)
                String[] data = curLine.split("\t");
                label.add(new Pair<>(data[0], data[1]));
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return label;
	}
	
	public void micro_avg_score(List<Pair<String, String>> ground_truths,
            List<Pair<String, String>> predictions,
            boolean by_triplet, double conf) throws IOException {
		int tp = 0, num_truth = 0, num_pred = 0;
		int num_sample = ground_truths.size(); // == preds.size()
		for(int i=0; i<num_sample; i++) {

//            System.out.println(i+"\t======================");
            
			Pair<String, String> ground_truth = ground_truths.get(i);
			Pair<String, String> prediction = predictions.get(i);
			if(!ground_truth.getFirst().equals(prediction.getFirst())){
				throw new RuntimeException("INDEX CONFLICT ! T:"+ground_truth.getFirst()+"!=P:"+prediction.getFirst());
			}
			
			List<String> tlist = new ArrayList<>(Arrays.asList(ground_truth.getSecond().split(",")));
			List<String> plist = new ArrayList<>(Arrays.asList(prediction.getSecond().split(",")));
			tlist.remove("None");
			plist.remove("None");
			
			plist = thresholding(plist, conf);
			
			num_truth += tlist.size();
			num_pred += plist.size();
			
			tp += calc_tp(tlist, plist, by_triplet);
		}

//		System.out.println("recall: "+tp+"/"+num_truth);
//		System.out.println("precision: "+tp+"/"+num_pred);
		double recall = (double) tp / num_truth;
		double precision = (double) tp / num_pred;
	/*	System.out.printf("MICRO-AVERAGED PRECISION = %f%% (%d/%d)\n", precision, tp, num_pred);
		System.out.printf("MICRO-AVERAGED RECALL = %f%% (%d/%d)\n", recall, tp, num_truth);
		System.out.printf("MICRO-AVERAGED F1-SCORE = %f%%\n", (2*recall*precision / (recall+precision)));*/
		System.out.println(String.format("%.2f\t%.2f\t%.2f",precision*100, recall*100, (2*recall*precision) /  (recall+precision) *100));
//		output_writer.write(String.format("%.1f\t%.2f\t%.2f\t%.2f",conf,precision*100, recall*100, (2*recall*precision) /  (recall+precision) *100));
//		output_writer.newLine();
	}
	
	public List<String> thresholding(List<String> list, double conf){
        List<String> filteredList = new ArrayList<>();
        for(String l : list){
            String t = l.split("@")[0];
            double c = Double.parseDouble(l.split("@")[1]);
            if(conf <= c)
                filteredList.add(t);
        }
        return filteredList;
    }

    public int calc_tp(List<String> tlist, List<String> plist, boolean by_triplet) {
        int tp = 0;
        for (String t : tlist) {
            String[] triplet_t = t.split("&");
            boolean flag = false;
            for (String p : plist) {
                String[] triplet_p = p.split("@")[0].split("&");
                
                //[0]:entity, [1]:entity, [2]:Relation
                //System.out.println(triplet_t[0]+"-"+triplet_p[0]);
                //System.out.println(triplet_t[1]+"-"+triplet_p[1]);
                if((triplet_t[0].equalsIgnoreCase(triplet_p[0]) 
                		&& triplet_t[1].equalsIgnoreCase(triplet_p[1]))
                	||(triplet_t[1].equalsIgnoreCase(triplet_p[0])
                		&& triplet_t[0].equalsIgnoreCase(triplet_p[1])))
                {
                	flag = true;
                	if(by_triplet)
                	{
                		if(!triplet_t[2].equalsIgnoreCase(triplet_p[2]))
                			flag = false;
                	}
                	if(flag) {
                		plist.remove(p);
                		break;
                	}
                }
                /*System.out.println(flag);
                System.out.println("----------------------------------");*/
            }
            if (flag)
                tp ++;
        }
        return tp;
    }
    public void run(String ground_truth_path, String prediction_path) throws IOException{
        // READ DATA
//    	output_writer = new BufferedWriter(new FileWriter(new File(output_path)));
        DataHelpers dataHelpers = new DataHelpers();
        dataHelpers.load_data(ground_truth_path);
         
        System.out.println("========= triplet evaluation =========");
        System.out.println("precision\trecall\tfscore");
        evaluation(ground_truth_path, prediction_path, 0.0, true);
        
        System.out.println("========= pair evaluation =========");
        System.out.println("precision\trecall\tfscore");
        evaluation(ground_truth_path, prediction_path, 0.0, false);
        
        
        /*Double[] threshold = {0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9};
        output_writer.write(">>triplet");
        output_writer.newLine();
        output_writer.write("conf\tprecision\trecall\tfscore");
        output_writer.newLine();
        for(double confidence : threshold)
        {
        	evaluation(ground_truth_path, prediction_path, confidence, true);
        }*/
        /*output_writer.newLine();
        output_writer.write(">>pair");
        output_writer.newLine();
        output_writer.write("conf\tprecision\trecall\tfscore");
        output_writer.newLine();
        for(double confidence : threshold)
        {
        	evaluation(ground_truth_path, prediction_path, confidence, false);
        }
        output_writer.flush();
        output_writer.close();*/
        
    }
    
    public void evaluation(String ground_truth_path, String prediction_path
    			, double confidence_threshold, Boolean triplet) throws IOException
    {
        List<Pair<String, String>> truths = get_truth(ground_truth_path);
        List<Pair<String, String>> preds = get_prediction(prediction_path);
        
        if(!triplet) {
//      System.out.println("\n[ Evaluate by Pair ]");
//      macro_avg_score(truths, preds, false, config.CONFIDENCE_THRESHOLD);
        	micro_avg_score(truths, preds, false, confidence_threshold);
        }
        else {
//        System.out.println("\n[ Evaluate by Triplet ] ");
//        macro_avg_score(truths, preds, true, config.CONFIDENCE_THRESHOLD);
        	micro_avg_score(truths, preds, true, confidence_threshold);
        }
    }
    
	private static void printNumOfPositiveSentence(List<Boolean> l)
	{
		int count = 0;
		for(int i = 0 ; i < l.size() ; i++)
		{
			if(l.get(i))
				count++;
		}
//		System.out.println("The number of positive sentences: "+count+"/"+l.size());
	}
}
