package TPE;

import java.util.ArrayList;
import java.util.List;

public class PatternNode
{
    private int UID;
    private String USTRING;
    private int PID;
    private int Children_Order;
    private String Notation;
    private int Post_ID;
    private int height;
    private ArrayList<Integer> Children;
    
    PatternNode() {
        this.Children = new ArrayList<Integer>();
    }
    
    PatternNode(final int UID, final String USTRING, final int PID, final int CO, final String Notation, final int Post_ID) {
        this.setUID(UID);
        this.setUSTRING(USTRING);
        this.setPID(PID);
        this.setChildren_Order(CO);
        this.setNotation(Notation);
        this.setPost_ID(Post_ID);
        this.setHeight(-1);
        this.Children = new ArrayList<Integer>();
    }
    
    PatternNode(final int UID, final String USTRING, final int PID, final int CO, final String Notation, final int Post_ID, final int Height) {
        this.setUID(UID);
        this.setUSTRING(USTRING);
        this.setPID(PID);
        this.setChildren_Order(CO);
        this.setNotation(Notation);
        this.setPost_ID(Post_ID);
        this.setHeight(Height);
        this.Children = new ArrayList<Integer>();
    }
    
    public int getUID() {
        return this.UID;
    }
    
    public void setUID(final int uID) {
        this.UID = uID;
    }
    
    public String getUSTRING() {
        return this.USTRING;
    }
    
    public void setUSTRING(final String uSTRING) {
        this.USTRING = uSTRING;
    }
    
    public int getPID() {
        return this.PID;
    }
    
    public void setPID(final int pID) {
        this.PID = pID;
    }
    
    public int getChildren_Order() {
        return this.Children_Order;
    }
    
    public void setChildren_Order(final int children_Order) {
        this.Children_Order = children_Order;
    }
    
    public String getNotation() {
        return this.Notation;
    }
    
    public void setNotation(final String notation) {
        this.Notation = notation;
    }
    
    public int getPost_ID() {
        return this.Post_ID;
    }
    
    public void setPost_ID(final int post_ID) {
        this.Post_ID = post_ID;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public void setHeight(final int height) {
        this.height = height;
    }
    
    public ArrayList<Integer> getChildren() {
        return this.Children;
    }
    
    public void setChildren(final ArrayList<Integer> children) {
        this.Children = children;
    }
    
    public void Addchildren(final Integer child) {
        this.Children.add(child);
    }
    
    public int PostOrderTrvs(final List<PatternNode> tree, int NumOfNodes) {
        int Post_ID = -1;
        int cur_height = -1;
        int Max_Children_height = -1;
        for (int i = 0; i < this.Children.size(); ++i) {
            final int Cur_Child_Post_ID = NumOfNodes = tree.get(this.Children.get(i)).PostOrderTrvs(tree, NumOfNodes);
            if (Max_Children_height < tree.get(this.Children.get(i)).getHeight()) {
                Max_Children_height = tree.get(this.Children.get(i)).getHeight();
            }
        }
        if (this.Children.size() == 0) {
            cur_height = 1;
        }
        else if (this.getUSTRING().equals("!") || this.getUSTRING().equals("*")) {
            cur_height = Max_Children_height;
        }
        else {
            cur_height = Max_Children_height + 1;
        }
        this.setHeight(cur_height);
        Post_ID = NumOfNodes + 1;
        this.setPost_ID(Post_ID);
        for (int i = 0; i < this.Children.size(); ++i) {
            tree.get(this.Children.get(i)).setPID(Post_ID);
        }
        return Post_ID;
    }
    
    public void PostOrderInsert(final List<PatternNode> PostTree, final List<PatternNode> tree) {
        for (int i = 0; i < this.Children.size(); ++i) {
            tree.get(this.Children.get(i)).PostOrderInsert(PostTree, tree);
        }
        final PatternNode node = new PatternNode(this.getUID(), this.getUSTRING(), this.getPID(), this.getChildren_Order(), this.getNotation(), this.getPost_ID(), this.getHeight());
        PostTree.add(node);
    }
}
