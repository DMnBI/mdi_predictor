package TPE;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import Main.Configure;

class TPEPattern {
	List<Pattern> patternList;

	public TPEPattern(Configure config){
		patternList = new ArrayList<>();
		JSONParser parser = new JSONParser();

		try{
			JSONObject obj = (JSONObject) parser.parse(new FileReader(config.TPE_PATTERN_PATH));

			JSONArray data = (JSONArray) obj.get("data");
			for (int i=0; i<data.size(); i++){
				JSONObject jsonPattern = (JSONObject) data.get(i);
				String name = (String) jsonPattern.get("name");
				String pattern = (String) jsonPattern.get("pattern");
				String desc = (String) jsonPattern.get("description");
				int index = ((Long) jsonPattern.get("index")).intValue();

				int iter = 4;
				for (int j=0; j<iter; j++) {
					String newPattern = pattern;
					for (int k=0; k<iter; k++) {
						patternList.add(new Pattern(name, newPattern, desc, index));
						newPattern = newPattern.replaceFirst("bac00", "bac00.+> * <n.+ bac00");
					}
					pattern = pattern.replaceFirst("dis00", "dis00.+> * <n.+ dis00");
				}
			}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
	}
}

class Pattern {
	String name;
	String pattern;
	String description;
	Integer index;

	Pattern(String name, String pattern, String description, Integer confidence) {
		this.name = name;
		this.pattern = pattern;
		this.description = description;
		this.index = confidence;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
}