package TPE;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class PatternQuery
{
    public StringTokenizer st;
    public int NumberOfPatterns;
    private List<PatternNode> Matchlist;
    
    PatternQuery() {
        this.NumberOfPatterns = 0;
    }
    
    PatternQuery(final StringTokenizer st) {
        this.st = st;
        this.NumberOfPatterns = 0;
        this.Matchlist = new ArrayList<PatternNode>();
        final PatternNode junk = new PatternNode(-1, "", -1, -1, "", -1);
        this.Matchlist.add(junk);
    }
    
    public List<PatternNode> getMatchlist() {
        return this.Matchlist;
    }
    
    public void setMatchlist(final List<PatternNode> matchlist) {
        this.Matchlist = matchlist;
    }
    
    public int SepPattern(final List<PatternNode> tree, final int PID) {
        int NOC = 0;
        int Children_order = 0;
        int UID = 0;
        while (this.st.hasMoreTokens()) {
            if (NOC != 0) {
                --NOC;
                break;
            }
            String CurToken = this.st.nextToken();
            String Notation = null;
            ++this.NumberOfPatterns;
            UID = this.NumberOfPatterns;
            ++Children_order;
            if (CurToken.charAt(0) == '*') {
                int chk = 0;
                int cchk = 0;
                for (int i = 0; i < CurToken.length(); ++i) {
                    if (CurToken.charAt(i) == '<' || CurToken.charAt(i) == '{') {
                        ++chk;
                    }
                    if (CurToken.charAt(i) == '>' || CurToken.charAt(i) == '}') {
                        ++cchk;
                    }
                }
                if (chk != 0) {
                    NOC = this.InsertPTE(CurToken, tree, PID, Children_order);
                }
                else if (cchk != 0) {
                    NOC = 0;
                    int cpcnt = 0;
                    final List<String> close_parenthesis = new ArrayList<String>();
                    while (CurToken.charAt(CurToken.length() - 1) == '>' || CurToken.charAt(CurToken.length() - 1) == '}') {
                        ++NOC;
                        ++cpcnt;
                        close_parenthesis.add(CurToken.substring(CurToken.length() - 1, CurToken.length()));
                        CurToken = CurToken.substring(0, CurToken.length() - 1);
                    }
                    Notation = "*";
                    final PatternNode tmp = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
                    tree.add(tmp);
                    this.Matchlist.add(tmp);
                    tree.get(PID).Addchildren(UID);
                    this.InsertAnytree(tree, UID);
                    for (int j = 0; j < cpcnt; ++j) {
                        final PatternNode CPNode = new PatternNode(-1, close_parenthesis.get(j), -1, -1, "", -1);
                        this.Matchlist.add(CPNode);
                    }
                }
                else {
                    Notation = "*";
                    final PatternNode tmp2 = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
                    tree.add(tmp2);
                    this.Matchlist.add(tmp2);
                    tree.get(PID).Addchildren(UID);
                    this.InsertAnytree(tree, UID);
                }
            }
            else if (CurToken.charAt(0) == '!') {
                NOC = this.InsertPTE(CurToken, tree, PID, Children_order);
            }
            else if (CurToken.charAt(0) == '<') {
                Notation = "tree";
                final String open_parenthesis = CurToken.substring(0, 1);
                final PatternNode OPNode = new PatternNode(-1, open_parenthesis, -1, -1, "", -1);
                this.Matchlist.add(OPNode);
                CurToken = CurToken.substring(1);
                final PatternNode tmp2 = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
                tree.add(tmp2);
                this.Matchlist.add(tmp2);
                tree.get(PID).Addchildren(UID);
                NOC = this.SepPattern(tree, UID);
            }
            else if (CurToken.charAt(CurToken.length() - 1) == '>' || CurToken.charAt(CurToken.length() - 1) == '}') {
                NOC = 0;
                int cpcnt2 = 0;
                final List<String> close_parenthesis2 = new ArrayList<String>();
                while (CurToken.charAt(CurToken.length() - 1) == '>' || CurToken.charAt(CurToken.length() - 1) == '}') {
                    ++NOC;
                    ++cpcnt2;
                    close_parenthesis2.add(CurToken.substring(CurToken.length() - 1, CurToken.length()));
                    CurToken = CurToken.substring(0, CurToken.length() - 1);
                }
                Notation = "leaf";
                final PatternNode tmp2 = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
                tree.add(tmp2);
                this.Matchlist.add(tmp2);
                tree.get(PID).Addchildren(UID);
                for (int k = 0; k < cpcnt2; ++k) {
                    final PatternNode CPNode2 = new PatternNode(-1, close_parenthesis2.get(k), -1, -1, "", -1);
                    this.Matchlist.add(CPNode2);
                }
            }
            else if (CurToken.charAt(0) == '{') {
                Notation = "cut";
                final String open_parenthesis = CurToken.substring(0, 1);
                final PatternNode OPNode = new PatternNode(-1, open_parenthesis, -1, -1, "", -1);
                this.Matchlist.add(OPNode);
                CurToken = CurToken.substring(1);
                final PatternNode tmp2 = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
                tree.add(tmp2);
                this.Matchlist.add(tmp2);
                tree.get(PID).Addchildren(UID);
                NOC = this.SepPattern(tree, UID);
            }
            else if (CurToken.charAt(CurToken.length() - 1) == '>' || CurToken.charAt(CurToken.length() - 1) == '}') {
                NOC = 0;
                while (CurToken.charAt(CurToken.length() - 1) == '>' || CurToken.charAt(CurToken.length() - 1) == '}') {
                    ++NOC;
                    final String close_parenthesis3 = CurToken.substring(CurToken.length() - 1, CurToken.length());
                    final PatternNode CPNode3 = new PatternNode(-1, close_parenthesis3, -1, -1, "", -1);
                    this.Matchlist.add(CPNode3);
                    CurToken = CurToken.substring(0, CurToken.length() - 1);
                }
                Notation = "leaf";
                final PatternNode tmp3 = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
                tree.add(tmp3);
                this.Matchlist.add(tmp3);
                tree.get(PID).Addchildren(UID);
            }
            else {
                Notation = "leaf";
                final PatternNode tmp3 = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
                tree.add(tmp3);
                this.Matchlist.add(tmp3);
                tree.get(PID).Addchildren(UID);
            }
        }
        return NOC;
    }
    
    public void InsertAnytree(final List<PatternNode> tree, final int PID) {
        final int Children_order = 1;
        ++this.NumberOfPatterns;
        final int UID = this.NumberOfPatterns;
        final String Notation = "anytree";
        final String CurToken = "anytree";
        final PatternNode tmp = new PatternNode(UID, CurToken, PID, Children_order, Notation, -1);
        tree.add(tmp);
        this.Matchlist.add(tmp);
        tree.get(PID).Addchildren(UID);
    }
    
    public int InsertPTE(String CurToken, final List<PatternNode> tree, int PID, int Children_Order) {
        int NOC = 0;
        String Notation = null;
        int chk = 0;
        int UID = 0;
        if (CurToken.charAt(0) == '*') {
            Notation = "*";
            CurToken = CurToken.substring(1);
            UID = this.NumberOfPatterns;
            final PatternNode tmp = new PatternNode(UID, "*", PID, Children_Order, Notation, -1);
            this.Matchlist.add(tmp);
            tree.add(tmp);
            tree.get(PID).Addchildren(UID);
            PID = UID;
            ++this.NumberOfPatterns;
            Children_Order = 1;
            ++chk;
        }
        if (CurToken.charAt(0) == '!') {
            Notation = "!";
            CurToken = CurToken.substring(1);
            if (chk != 0) {
                UID = this.NumberOfPatterns;
                final PatternNode tmp = new PatternNode(UID, "!", PID, Children_Order, Notation, -1);
                this.Matchlist.add(tmp);
                tree.add(tmp);
                tree.get(PID).Addchildren(UID);
                PID = UID;
                ++this.NumberOfPatterns;
                Children_Order = 1;
            }
            else {
                UID = this.NumberOfPatterns;
                final PatternNode tmp = new PatternNode(UID, "!", PID, Children_Order, Notation, -1);
                this.Matchlist.add(tmp);
                tree.add(tmp);
                tree.get(PID).Addchildren(UID);
                PID = UID;
                ++this.NumberOfPatterns;
                Children_Order = 1;
            }
        }
        if (CurToken.charAt(0) == '<') {
            Notation = "tree";
            UID = this.NumberOfPatterns;
            final String open_parenthesis = CurToken.substring(0, 1);
            final PatternNode OPNode = new PatternNode(-1, open_parenthesis, -1, -1, "", -1);
            this.Matchlist.add(OPNode);
            CurToken = CurToken.substring(1);
            final PatternNode tmp2 = new PatternNode(UID, CurToken, PID, Children_Order, Notation, -1);
            this.Matchlist.add(tmp2);
            tree.add(tmp2);
            tree.get(PID).Addchildren(UID);
            ++PID;
        }
        if (CurToken.charAt(0) == '{') {
            Notation = "cut";
            UID = this.NumberOfPatterns;
            final String open_parenthesis = CurToken.substring(0, 1);
            final PatternNode OPNode = new PatternNode(-1, open_parenthesis, -1, -1, "", -1);
            this.Matchlist.add(OPNode);
            CurToken = CurToken.substring(1);
            final PatternNode tmp2 = new PatternNode(UID, CurToken, PID, Children_Order, Notation, -1);
            this.Matchlist.add(tmp2);
            tree.add(tmp2);
            tree.get(PID).Addchildren(UID);
            ++PID;
        }
        NOC = this.SepPattern(tree, PID);
        return NOC;
    }
}
