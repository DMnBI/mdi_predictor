package TPE;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeCoreAnnotations.TreeAnnotation;
import edu.stanford.nlp.util.CoreMap;

public class Parser {
	static Properties props;
	static StanfordCoreNLP pipeline;
	static Annotation annotation;

	String ParseTree;
	StringTokenizer tokenizedParseTree;

	int pre_order_counter;

	public Parser(){
		// creates a StanfordCoreNLP object,
		// with POS tagging, lemmatization, NER, parsing, and coreference resolution.
		props = new Properties();
		props.setProperty("annotators", "tokenize, ssplit, pos, lemma, ner, parse, dcoref");
		props.put("tokenize.whitespace", "true");
		pipeline = new StanfordCoreNLP(props);
	}

	public List<TreeNode> transformPostTree(String parse_sentence) {
		ParseTree = parse_sentence;
		pre_order_counter = 0;
		return makePostOrderTree();
	}

	public String makeParseTree(String sentence) {
		// create an empty Annotation just with the given text
		annotation = new Annotation(sentence);

		// run all Annotators on this text
		pipeline.annotate(annotation);

		// a CoreMap is essentially a Map that uses class objects as keys and has values with custom types
		CoreMap s = annotation.get(SentencesAnnotation.class).get(0);
		// this is the parse tree of the current sentence
		Tree tree = s.get(TreeAnnotation.class);

		return tree.toString();
	}

	public List<TreeNode> makePostOrderTree() {
		tokenizedParseTree = new StringTokenizer(ParseTree, " ");

		// �봽由ъ삤�뜑 �끂�뱶由ъ뒪�듃瑜� �뼸�쓣 �닔 �엳�떎.
		// makePreOrderList()�쓽 3踰덉㎏ parameter�뿉 �꽔�� 由ъ뒪�듃�뿉 �봽由ъ삤�뜑濡� �궫�엯�맂�떎.
		List<TreeNode> pre_tree = new ArrayList<TreeNode>();
		TreeNode junk = new TreeNode(-1, "", -1, -1, 0, -1);
		pre_tree.add(junk);
		makePreOrderList(0, pre_tree);

		// �룷�뒪�듃�삤�뜑 �깘�깋�븯硫댁꽌 POST_ID 媛� �엯
		PostOrderTrvs(1, 0, pre_tree);

		// �쐞�뿉�꽌 �엯�젰�빐�넃�� POST_ID瑜� 湲곕컲�쑝濡� Post Ordered 由ъ뒪�듃瑜� �뼸�뒗�떎.
		List<TreeNode> post_tree = new ArrayList<TreeNode>();
		post_tree.add(junk);
		makePostOrderList(1, pre_tree, post_tree);

		// �옄�떊�쓽 遺�紐⑤끂�뱶�쓽 Child由ъ뒪�듃�뿉 �옄�떊�쓣 異붽��븳�떎.
		for (int i = 1; i < post_tree.size(); i++) {
			post_tree.get(post_tree.get(i).getPID()).addChildren(i);
		}

		return post_tree;
	}

	public int PostOrderTrvs(int pre_order_id, int post_order_counter, List<TreeNode> pre_tree) {
		TreeNode curNode = pre_tree.get(pre_order_id);

		int max_children_height = 0;
		for(int child_id : curNode.getChildren()){
			TreeNode childNode = pre_tree.get(child_id);
			int Cur_Child_Post_ID = PostOrderTrvs(child_id, post_order_counter, pre_tree);
			post_order_counter = Cur_Child_Post_ID;
			max_children_height = Math.max(max_children_height, childNode.getHeight());
		}
		curNode.setHeight(max_children_height + 1);

		int Post_ID = post_order_counter + 1;
		curNode.setPost_ID(Post_ID);

		// PID Update
		// PID : Parent Post ID
		for(int child_id : curNode.getChildren()){
			pre_tree.get(child_id).setPID(Post_ID);
		}

		return Post_ID;
	}

	public void makePostOrderList(int pre_order_id, List<TreeNode> pre_tree, List<TreeNode> post_tree) {
		TreeNode curNode = pre_tree.get(pre_order_id);

		for (int child_id : curNode.getChildren()) {
			makePostOrderList(child_id, pre_tree, post_tree);
		}

		String CurStr = curNode.getUSTRING();
		if(CurStr.contains("'")){
			CurStr = CurStr.replace("'", "\\'");
			curNode.setUSTRING(CurStr);
		}

		post_tree.add(curNode);
	}

	public int makePreOrderList(int parent_id, List<TreeNode> pre_tree){
		int close_bracket_num = 0;
		int Children_order = 0;
		while(tokenizedParseTree.hasMoreTokens()){
			if(close_bracket_num != 0){
				close_bracket_num --;
				break;
			}
			String curToken = tokenizedParseTree.nextToken();
			pre_order_counter++;

			// �넗�겙�쓽 �떆�옉�씠 ( �씤 寃쎌슦.
			if(curToken.charAt(0)=='('){
				// �옄�떇�쓽 �닔瑜� �븯�굹 �뒛由ш퀬,
				Children_order ++;
				// '('瑜� �옒�씪�궦�떎.
				curToken = curToken.substring(1);

				pre_tree.add(new TreeNode(pre_order_counter, curToken, parent_id, Children_order, -1, -1));
				pre_tree.get(parent_id).addChildren(pre_order_counter);

				close_bracket_num = makePreOrderList(pre_order_counter, pre_tree);
			}
			else if(curToken.charAt(curToken.length()-1)==')'){
				// �옄�떇�쓽 �닔瑜� �븯�굹 �뒛由ш퀬,
				Children_order ++;

				// ')'�쓽 媛쒖닔瑜� �꽱�떎.
				close_bracket_num = 0;
				while(curToken.charAt(curToken.length()-1) ==')'){
					close_bracket_num++;
					curToken = curToken.substring(0, curToken.length()-1);
				}

				pre_tree.add(new TreeNode(pre_order_counter, curToken, parent_id, Children_order, -1, -1));
				pre_tree.get(parent_id).addChildren(pre_order_counter);
			}
		}
		return close_bracket_num;
	}
}
