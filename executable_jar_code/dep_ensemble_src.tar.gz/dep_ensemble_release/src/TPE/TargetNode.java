package TPE;

import java.util.ArrayList;
import java.util.List;

public class TargetNode
{
    private int UID;
    private String USTRING;
    private int PID;
    private int Children_Order;
    private int Post_ID;
    private int height;
    private List<Integer> Children;
    
    public TargetNode(final int uID, final String uSTRING, final int pID, final int children_Order, final int post_ID, final int height) {
        this.UID = uID;
        this.USTRING = uSTRING;
        this.PID = pID;
        this.Children_Order = children_Order;
        this.Post_ID = post_ID;
        this.height = height;
        this.Children = new ArrayList<>();
    }

    
    public int getUID() {
        return this.UID;
    }
    
    public void setUID(final int uID) {
        this.UID = uID;
    }
    
    public String getUSTRING() {
        return this.USTRING;
    }
    
    public void setUSTRING(final String uSTRING) {
        this.USTRING = uSTRING;
    }
    
    public int getPID() {
        return this.PID;
    }
    
    public void setPID(final int pID) {
        this.PID = pID;
    }
    
    public int getChildren_Order() {
        return this.Children_Order;
    }
    
    public void setChildren_Order(final int children_Order) {
        this.Children_Order = children_Order;
    }
    
    public int getPost_ID() {
        return this.Post_ID;
    }
    
    public void setPost_ID(final int post_ID) {
        this.Post_ID = post_ID;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public void setHeight(final int height) {
        this.height = height;
    }
    
    public List<Integer> getChildren() {
        return this.Children;
    }
    
    public void setChildren(final List<Integer> children) {
        this.Children = children;
    }
    
    public void addChildren(final int Child) {
        this.Children.add(Child);
    }
}
