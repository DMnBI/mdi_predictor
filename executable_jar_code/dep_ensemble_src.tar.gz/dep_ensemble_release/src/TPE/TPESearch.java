package TPE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import Main.Configure;
import edu.stanford.nlp.process.Morphology;
import utils.Stemmer;
import utils.Pair;
import utils.Triplet;

public class TPESearch {
	public Parser parser;
	public Morphology stemmer;
	public Configure config;
	
	public TPESearch(Configure config){
		parser = new Parser();
		stemmer = new Morphology();
		
		this.config = config;
	}

	public List<Pair<Triplet, Integer>> tpe_search(String parse_sentence)
	{
		TPEPattern tpePattern = new TPEPattern(config);

		final List<Pattern> Patterns = tpePattern.patternList;

		List<TreeNode> QueryTree = parser.transformPostTree(parse_sentence);
		List<Pair<Triplet, Integer>> matchedResults = new ArrayList<>();

		for (int i = 0; i < Patterns.size(); ++i) {
			// TPE Query濡� sentence_post�뀒�씠釉붿뿉 ���빐 TPE Matching �떆�옉
			Pattern p = Patterns.get(i);

			final List<PatternNode> tree = new ArrayList<>();
			final PatternNode junk = new PatternNode(-1, "", -1, -1, "", -1);
			tree.add(junk);
			final StringTokenizer st = new StringTokenizer(p.pattern, " ");
			final PatternQuery PQuery = new PatternQuery(st);
			PQuery.SepPattern(tree, 0);
			tree.get(1).PostOrderTrvs(tree, 0);
			List<PatternNode> MatchList = PQuery.getMatchlist();

			final List<PatternNode> MatchList2 = new ArrayList<>();
			MatchList2.add(junk);
			for (int j = 1; j < tree.size(); ++j) {
				for (int k = 1; k < MatchList.size(); ++k) {
					if (tree.get(j).getUID() == MatchList.get(k).getUID()) {
						MatchList.set(k, tree.get(j));
						break;
					}
				}
			}
			for (int j = 0; j < MatchList.size(); ++j) {
				if (MatchList.get(j).getNotation().equals("leaf")) {
					MatchList2.add(MatchList.get(j));
				}
			}
			MatchList = MatchList2;

			final List<PatternNode> PostTree = new ArrayList<>();
			PostTree.add(junk);
			tree.get(1).PostOrderInsert(PostTree, tree);
			for (int k = 1; k < PostTree.size(); ++k) {
				PostTree.get(PostTree.get(k).getPID()).Addchildren(k);
			}

			List<Triplet> matchList = matching(QueryTree, PostTree, MatchList);
			Stemmer stemmer = new Stemmer();
			for (Triplet tri : matchList){
				tri.relation = stemmer.getStem(tri.relation); 
				matchedResults.add(new Pair<>(tri, tpePattern.patternList.get(i).index));
//				System.out.println(tpePattern.patternList.get(i).pattern);
			}
		}

		return matchedResults;
	}

	public List<Triplet> matching(final List<TreeNode> QueryTree, final List<PatternNode> PostTree, final List<PatternNode> MatchList) {
		List<TargetNode> TargetTree = new ArrayList<>();
		List<Integer> targetUIdList = new ArrayList<>();
		List<Integer> HighListUIDList = new ArrayList<>();

		for (TreeNode t : QueryTree){
			String stemed_word = t.getUSTRING();
			if(!stemed_word.equals("_"))
				stemed_word = stemmer.stem(stemed_word);
			final TargetNode TNode = new TargetNode(t.getUID(), stemed_word, t.getPID(), t.getChildren_Order(), t.getPost_ID(), t.getHeight());
			TargetTree.add(TNode);
		}
		for (int i = 1; i < TargetTree.size(); i++) {
			TargetTree.get(TargetTree.get(i).getPID()).addChildren(i);
			targetUIdList.add(TargetTree.get(i).getUID());
		}

		final Matcher matcher = new Matcher();
		List<Pairs> Result = matcher.treePatternMatch(PostTree, TargetTree);

		final List<Integer> Resulta = new ArrayList<>();
		final List<Integer> Resultb = new ArrayList<>();
		for (int i = 0; i < Result.size(); ++i) {
			Resulta.add(Result.get(i).P);
			Resultb.add(Result.get(i).T);
		}

		for (int i = 0; i < MatchList.size(); i++) {
			int curMatchIdx = MatchList.get(i).getPost_ID();
			if(Resulta.contains(curMatchIdx)){
				int RAIdx = Resulta.indexOf(curMatchIdx);
				int RBPostID = Resultb.get(RAIdx);
				int TGUID = targetUIdList.get(RBPostID-1);
				HighListUIDList.add(TGUID);
			}
		}

		List<String> relationWords = new ArrayList<>();
		List<String> bacteriaEntities = new ArrayList<>();
		List<String> diseaseEntities = new ArrayList<>();
		Set<String> stopWords = new HashSet<>(
				Arrays.asList(
						",","and","be","for","have","before","at","as","between",
						"number","of","one","that","to","which","after","into", "-lrb-", "-rrb"));

		for (TreeNode n : QueryTree) {
			for (int uid : HighListUIDList) {
				if (n.getUID() == uid) {
					String word = n.getUSTRING();
					if(word.length() > 5 && word.substring(0, 5).equals("BAC00")){
						bacteriaEntities.add(word);
					} else if(word.length() > 5 && word.substring(0, 5).equals("DIS00")) {
						diseaseEntities.add(word);
					}
					else {
						String stem_word = stemmer.stem(word);
						if(!stopWords.contains(stem_word)){
							relationWords.add(word);
						}
					}
				}
			}
		}

		List<Triplet> relationTriplets = new ArrayList<>();
		for (String bac : bacteriaEntities) {
			for (String dis : diseaseEntities) {
				for (String rel : relationWords) {
					relationTriplets.add(new Triplet(bac, dis, rel.toLowerCase()));
				}
			}
		}

		return relationTriplets;
	}

	public static void main(final String[] args) {
//		TPESearch t = new TPESearch();
//
//		String input = "The highest mortality from DIS00stomach_cancer is concentrated in the poorest regions of Peru, where it is probable that living conditions facilitate the high communicability of BAC00Helicobacter_pylori .";
//		List<Pair<Triplet, Integer>> results = t.tpe_search(input);
//		for(Pair<Triplet, Integer> result : results) {
//			System.out.printf("(%s-%s-%s) / confidence=%d\n",
//					result.getFirst().getBacteria(),
//					result.getFirst().getDisease(),
//					result.getFirst().getRelation(), result.getSecond());
//		}
	}

}
