package TPE;

class Pairs
{
    int Isnil;
    int Isfails;
    int P;
    int T;
    
    Pairs() {
    }
    
    public int getIsnil() {
        return this.Isnil;
    }
    
    public void setIsnil(final int isnil) {
        this.Isnil = isnil;
    }
    
    public int getIsfails() {
        return this.Isfails;
    }
    
    public void setIsfails(final int isfails) {
        this.Isfails = isfails;
    }
    
    public int getP() {
        return this.P;
    }
    
    public void setP(final int p) {
        this.P = p;
    }
    
    public int getT() {
        return this.T;
    }
    
    public void setT(final int t) {
        this.T = t;
    }
    
    public void setfails() {
        this.Isnil = 0;
        this.Isfails = 1;
    }
    
    public void setnil() {
        this.Isnil = 1;
        this.Isfails = 0;
    }
    
    Pairs(final int p, final int t) {
        this.setIsfails(0);
        this.setIsnil(0);
        this.setP(p);
        this.setT(t);
    }
}
