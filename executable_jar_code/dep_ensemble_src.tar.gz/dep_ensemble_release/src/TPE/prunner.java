package TPE;

import edu.stanford.nlp.process.Morphology;

import java.util.ArrayList;
import java.util.List;

public class prunner
{
    private List<PatternNode> PostTree;
    private List<String> PrunFactors;
    private String pattern;
    
    public List<PatternNode> getPostTree() {
        return this.PostTree;
    }
    
    public void setPostTree(final List<PatternNode> postTree) {
        this.PostTree = postTree;
    }
    
    public List<String> getPrunFactors() {
        return this.PrunFactors;
    }
    
    public void setPrunFactors(final List<String> prunFactors) {
        this.PrunFactors = prunFactors;
    }
    
    public void addPrunFactors(final String str) {
        this.PrunFactors.add(str);
    }
    
    public String getPattern() {
        return this.pattern;
    }
    
    public void setPattern(final String pattern) {
        this.pattern = pattern;
    }
    
    prunner() {
    }
    
    prunner(final List<PatternNode> PostTree) {
        this.setPostTree(PostTree);
        this.PrunFactors = new ArrayList<String>();
    }
    
    prunner(final String pattern) {
        this.setPattern(pattern);
    }
    
    public boolean IsPrunable() {
        int chk = 0;
        for (int i = 1; i < this.getPostTree().size(); ++i) {
            final String P = this.getPostTree().get(i).getUSTRING();
            if (!this.getPostTree().get(i).getUSTRING().equals("anytree")) {
                if (this.getPostTree().get(i).getNotation().equals("leaf")) {
                    if (!this.IsRE(this.getPostTree().get(i).getUSTRING())) {
                        chk = 1;
                        final Morphology id = new Morphology();
                        final String tmp = id.stem(this.getPostTree().get(i).getUSTRING());
                        this.PrunFactors.add(tmp);
                    }
                }
            }
        }
        return chk != 0;
    }
    
    public boolean IsRE(final String str) {
        return str.contains(".") || str.contains("\\") || str.contains("|") || str.contains("^") || str.contains("[") || str.contains("]") || str.contains("(") || str.contains(")") || str.contains("*") || str.contains("+") || str.contains("?") || str.contains("{") || str.contains(",") || str.contains("}");
    }
}
