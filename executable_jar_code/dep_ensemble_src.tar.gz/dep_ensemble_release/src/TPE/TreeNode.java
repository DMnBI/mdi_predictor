package TPE;

import java.util.ArrayList;
import java.util.List;

public class TreeNode {
	private int UID;
	private String USTRING;
	private int PID;
	private int Children_Order;
	private int Post_ID;
	private int height;
	private List<Integer> Children;
	
	
	public TreeNode() {
		this.Children = new ArrayList<Integer>();
	}
	
	public TreeNode(int uID, String uSTRING, int pID,int children_Order, int post_ID, int height) {
		super();
		UID = uID;
		USTRING = uSTRING;
		PID = pID;
		Children_Order = children_Order;
		Post_ID = post_ID;
		this.height = height;
		Children = new ArrayList<Integer>();
	}
	

	public int getUID() {
		return UID;
	}
	public void setUID(int uID) {
		UID = uID;
	}
	public String getUSTRING() {
		return USTRING;
	}
	public void setUSTRING(String uSTRING) {
		USTRING = uSTRING;
	}
	public int getPID() {
		return PID;
	}
	public void setPID(int pID) {
		PID = pID;
	}
	public int getChildren_Order() {
		return Children_Order;
	}
	public void setChildren_Order(int children_Order) {
		Children_Order = children_Order;
	}
	public int getPost_ID() {
		return Post_ID;
	}
	public void setPost_ID(int post_ID) {
		Post_ID = post_ID;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}


	public List<Integer> getChildren() {
		return Children;
	}
	public void setChildren(List<Integer> children) {
		Children = children;
	}
	public void addChildren(Integer Child){
		Children.add(Child);
	}
	
}
