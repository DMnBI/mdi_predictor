package TPE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Matcher {
    public HashMap<Integer, HashMap<Integer, List<Pairs>>> B;
    public HashMap<List<Integer>, HashMap<List<Integer>, List<Pairs>>> R;

    Matcher() {
        this.B = new HashMap<Integer, HashMap<Integer, List<Pairs>>>();
        this.R = new HashMap<List<Integer>, HashMap<List<Integer>, List<Pairs>>>();
    }

    public void init_B(final int i) {
        final HashMap<Integer, List<Pairs>> tmp = new HashMap<Integer, List<Pairs>>();
        this.B.put(i, tmp);
    }

    public void init_B(final int i, final int j) {
        final Pairs init_p = new Pairs();
        init_p.setfails();
        final List<Pairs> P = new ArrayList<Pairs>();
        P.add(init_p);
        this.B.get(i).put(j, P);
    }

    public void init_R(final List<Integer> x) {
        final HashMap<List<Integer>, List<Pairs>> tmp = new HashMap<List<Integer>, List<Pairs>>();
        this.R.put(x, tmp);
    }

    public void init_R(final List<Integer> x, final List<Integer> y) {
        final Pairs init_r = new Pairs();
        init_r.setnil();
        final List<Pairs> P = new ArrayList<Pairs>();
        P.add(init_r);
        this.R.get(x).put(y, P);
    }

    public void Insert_B(final int i, final int j, final List<Pairs> pairset) {
        final HashMap<Integer, List<Pairs>> tmp = new HashMap<Integer, List<Pairs>>();
        tmp.put(j, pairset);
        this.B.get(i).put(j, pairset);
    }

    public void Insert_R(final List<Integer> x, final List<Integer> y, final List<Pairs> pairset) {
        final HashMap<List<Integer>, List<Pairs>> tmp = new HashMap<List<Integer>, List<Pairs>>();
        tmp.put(y, pairset);
        this.R.get(x).put(y, pairset);
    }

    public int Head(final List<Integer> Seq) {
        return Seq.get(0);
    }

    public List<Integer> Tail(final List<Integer> Seq) {
        return Seq.subList(1, Seq.size());
    }

    public List<Integer> Children(final PatternNode PNode) {
        return PNode.getChildren();
    }

    public int Child(final PatternNode PNode) {
        return PNode.getChildren().get(0);
    }

    public List<Integer> Children(final TargetNode TNode) {
        return TNode.getChildren();
    }

    public int Child(final TargetNode TNode) {
        return TNode.getChildren().get(0);
    }

    public List<Pairs> treePatternMatch(final List<PatternNode> P, final List<TargetNode> T) {
        for (int i = 1; i < P.size(); ++i) {
            this.init_B(i);
            if (!P.get(i).getNotation().equals("*")) {
                for (int j = 1; j < T.size(); ++j) {
                    this.init_B(i, j);
                    final String notation;
                    switch (notation = P.get(i).getNotation()) {
                        case "anytree": {
                            final List<Pairs> pairset = new ArrayList<Pairs>();
                            this.Insert_B(i, j, pairset);
                            break;
                        }
                        case "!": {
                            if (this.B.get(this.Child(P.get(i))).get(j).size() != 0 && this.B.get(this.Child(P.get(i))).get(j).get(0).Isfails == 1) {
                                final List<Pairs> pairset2 = new ArrayList<Pairs>();
                                this.Insert_B(i, j, pairset2);
                                break;
                            }
                            break;
                        }
                        case "cut": {
                            if (T.get(j).getUSTRING().matches(P.get(i).getUSTRING())) {
                                this.Insert_B(i, j, this.match(this.Children(P.get(i)), this.Children(T.get(j)), true, P, T));
                                break;
                            }
                            break;
                        }
                        case "leaf": {
                            if (!P.get(i).getUSTRING().contains("/") && T.get(j).getChildren().size() == 0 && T.get(j).getUSTRING().matches(P.get(i).getUSTRING())) {
                                final List<Pairs> pairset3 = new ArrayList<Pairs>();
                                this.Insert_B(i, j, pairset3);
                                break;
                            }
                            break;
                        }
                        case "tree": {
                            if (T.get(j).getUSTRING().matches(P.get(i).getUSTRING())) {
                                this.Insert_B(i, j, this.match(this.Children(P.get(i)), this.Children(T.get(j)), false, P, T));
                                break;
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }
            }
        }
        final List<Pairs> Result = new ArrayList<Pairs>();
        if (this.B.size() != 0 && this.B.get(this.B.size()).size() != 0) {
            for (int k = this.B.get(this.B.size()).size(); k > 1; --k) {
                if (this.B.get(this.B.size()).get(k).size() != 0 && this.B.get(this.B.size()).get(k).get(0).Isfails != 1) {
                    this.PrintResult(this.B.size(), k, Result);
                }
            }
        }
        return Result;
    }

    public void PrintResult(final int i, final int j, final List<Pairs> Result) {
        if (this.B.get(i).get(j).size() == 0) {
            final Pairs tmp = new Pairs(i, j);
            Result.add(tmp);
        } else {
            final Pairs tmp = new Pairs(i, j);
            Result.add(tmp);
            for (int k = this.B.get(i).get(j).size() - 1; k >= 0; --k) {
                this.PrintResult(this.B.get(i).get(j).get(k).P, this.B.get(i).get(j).get(k).T, Result);
            }
        }
    }

    public List<Pairs> match(final List<Integer> x, final List<Integer> y, final boolean cut, final List<PatternNode> P, final List<TargetNode> T) {
        int chk = 0;
        if (this.R.get(x) == null) {
            this.init_R(x);
        } else if (this.R.get(x).get(y) != null) {
            return this.R.get(x).get(y);
        }
        this.init_R(x, y);
        this.R.get(x).get(y).get(0).setfails();

        if (x.size() == 0) {
            chk = 1;
            if (y.size() == 0) {
                final List<Pairs> pairset = new ArrayList<Pairs>();
                this.Insert_R(x, y, pairset);
            }
        } else if (P.get(this.Head(x)).getUSTRING().equals("*")) {
            chk = 1;
            List<Pairs> L = this.match(this.Tail(x), y, cut, P, T);
            int NOTFAIL = 0;
            if (L.size() == 0 || L.get(0).Isfails != 1) {
                this.Insert_R(x, y, L);
                ++NOTFAIL;
            }

            if (NOTFAIL == 0 && y.size() != 0) {
                if ((this.B.get(this.Child(P.get(this.Head(x)))).get(this.Head(y)).size() == 0)
                        || (this.B.get(this.Child(P.get(this.Head(x)))).get(this.Head(y)).get(0).Isfails != 1)){
                    L = this.match(x, this.Tail(y), cut, P, T);
                    if (L.size() == 0 || L.get(0).Isfails != 1) {
                        final Pairs a = new Pairs(this.Child(P.get(this.Head(x))), this.Head(y));
                        this.Insert_R(x, y, this.Union(L, a));
                    } else if (cut && x.size() != 0 && y.size() != 0 && T.get(this.Head(y)).getChildren().size() != 0) {
                        L = this.match(x, this.Cons(this.Children(T.get(this.Head(y))), this.Tail(y)), cut, P, T);
                        if (L.size() == 0 || L.get(0).Isfails != 1) {
                            this.Insert_R(x, y, L);
                        }
                    }
                }
            }
        } else if (y.size() != 0 && this.B.get(this.Head(x)).size() != 0) {
            if (this.B.get(this.Head(x)).get(this.Head(y)).size() == 0
                    || this.B.get(this.Head(x)).get(this.Head(y)).get(0).Isfails != 1) {
                chk = 1;
                List<Pairs> L = this.match(this.Tail(x), this.Tail(y), cut, P, T);
                if (L.size() == 0 || L.get(0).Isfails != 1) {
                    final Pairs a2 = new Pairs(this.Head(x), this.Head(y));
                    this.Insert_R(x, y, this.Union(L, a2));
                }
            }
        }
        if (cut && x.size() != 0 && y.size() != 0 && T.get(this.Head(y)).getChildren().size() != 0 && chk != 1) {
            List<Pairs> L = this.match(x, this.Cons(this.Children(T.get(this.Head(y))), this.Tail(y)), cut, P, T);

            if (L.size() == 0 || L.get(0).Isfails != 1) {
                this.Insert_R(x, y, L);
            }
        }
        return this.R.get(x).get(y);
    }

    public List<Integer> Cons(final List<Integer> x, final List<Integer> y) {
        final List<Integer> tmp = new ArrayList<Integer>();
        tmp.addAll(x);
        tmp.addAll(y);
        return tmp;
    }

    public List<Pairs> Union(final List<Pairs> L, final Pairs a) {
        final List<Pairs> tmp = new ArrayList<Pairs>();
        tmp.addAll(L);
        for (int i = 0; i < tmp.size(); ++i) {
            if (tmp.get(i).equals(a)) {
                return tmp;
            }
        }
        tmp.add(a);
        return tmp;
    }
}
