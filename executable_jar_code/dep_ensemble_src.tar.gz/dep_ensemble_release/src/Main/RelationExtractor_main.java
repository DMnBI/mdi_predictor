package Main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.cli.*;

import Evaluator.Evaluator;
import MDex.MDex;
import TPE.TPESearch;
import utils.Pair;
import utils.Stemmer;
import utils.Triplet;

public class RelationExtractor_main {
	
	private final static Logger LOG = Logger.getGlobal();
	
	public static String USAGE_MSG = "java -jar "+get_file_name()+" config.file";
	
	public static Configure config;
	public static Options options;
	
	public MDex mdex_extractor;
	public TPESearch tpe_extractor;
	public ConfidenceCalculator confidence_calculator;
	
	public RelationExtractor_main(Configure config)
	{
		this.config = config;
		
		if(this.config.USE_TPE)
			this.tpe_extractor = new TPESearch(config);
		if(this.config.USE_MDEX)
			this.mdex_extractor = new MDex(config);
		this.confidence_calculator = new ConfidenceCalculator();
	}
	
	private List<List<Pair<Triplet, Integer>>> extract_relation
			(List<String> corpus, List<String> parse_corpus
					, List<String> is_contain_relation)
	{
		//sentences passed by SVMFilter
		List<List<Pair<Triplet, Integer>>> extracted_relations = new ArrayList<>();
		for(int i = 0 ; i < corpus.size() ; i ++)
		{
			List<Pair<Triplet, Integer>> relations = new ArrayList<>();
			if(is_contain_relation.size() == 0)
			{
				if(this.config.USE_TPE) {
					relations.addAll(this.tpe_extractor.tpe_search(parse_corpus.get(i)));
				}
				if(this.config.USE_MDEX)
					relations.addAll(this.mdex_extractor.get_relation(corpus.get(i), null/*"output/dependency_graph/"+(i+1)+".png"*/));
			}
			else if(is_contain_relation.get(i).toLowerCase().equals("true"))
			{
				if(this.config.USE_TPE) {
					relations.addAll(this.tpe_extractor.tpe_search(parse_corpus.get(i)));
				}
				if(this.config.USE_MDEX)
					relations.addAll(this.mdex_extractor.get_relation(corpus.get(i), null/*"output/dependency_graph/"+(i+1)+".png"*/));
			}
			extracted_relations.add(relations);
		}
		return extracted_relations;
	}
	
	private void save_result(List<String> index
			, List<List<Pair<Triplet, Double>>> extracted_result)
	{
		Stemmer stemmer = new Stemmer();
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter
					(this.config.OUTPUT_RESULT_PATH));
			for(int i = 0 ; i < extracted_result.size() ; i ++)
			{
				bw.write(index.get(i)+"\t");
				List<Pair<Triplet, Double>> relations = extracted_result.get(i);
				if(relations.size() == 0)
					bw.write("None\n");
				else
				{
					for(int j = 0 ; j < relations.size() ; j++)
					{
						Triplet triplet = relations.get(j).getFirst();
						Double conf = relations.get(j).getSecond();
						
						String result = triplet.entity2 + "&" + triplet.entity1
								+ "&" + stemmer.getStem(triplet.relation);
						result += "@"+conf;
						result += j + 1 < relations.size() ? "," : "\n";
						bw.write(result);
					}
				}
			}
			bw.flush();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void train(List<String> corpus, List<String> parsed_corpus
			, List<String> label, Configure config)
	{
		//Confidence
		System.out.println("Building confidence table...");
		List<List<Pair<Triplet, Integer>>> extracted_realtions
			= this.extract_relation(corpus, parsed_corpus, new ArrayList<String>());
		this.confidence_calculator.build_confidence_table(extracted_realtions, label);
		this.confidence_calculator.save_confidence(config.CONFIDENCE_PATH);
		
		System.out.println("Saved confidence table!");
	}
	
	public void test(List<String> index, List<String> corpus
			, List<String> parsed_corpus 
			, List<String> is_contain_relation, Configure config)
	{
		
		System.out.println("Extracting relations with confidence filter...");
		List<List<Pair<Triplet, Integer>>> extracted_relations
			= this.extract_relation(corpus, parsed_corpus, is_contain_relation);
		List<List<Pair<Triplet, Double>>> results = new ArrayList<>();
		
		this.confidence_calculator.load_confidence(config.CONFIDENCE_PATH);
		
		for(List<Pair<Triplet, Integer>> relations : extracted_relations)
			results.add(this.confidence_calculator.confidence_filtering
					(relations, config.CONFIDENCE_THRESHOLD));
		
		this.save_result(index, results);
		System.out.println("Saved extracted results!");
		
	}
	
	public static void main(String[] args) throws ParseException, IOException
	{
			long start_time = System.currentTimeMillis();
			
			LOG.info("load configurations from config file.");
			
			Configure config = parsingCommand(args);
			RelationExtractor_main bdr_extractor = new RelationExtractor_main(config);

			DataHelpers dataHelpers = new DataHelpers();			
			
			switch(config.MODE)
			{
			case "train":
				config.print();
				dataHelpers.load_data(config.INPUT_DATA_PATH);
				System.out.println("Parsing corpus...");
				dataHelpers.load_parsed_corpus(config.PARSED_CORPUS_PATH);
				System.out.println("Start training!");
				bdr_extractor.train(dataHelpers.corpus, dataHelpers.parsed_corpus
						, dataHelpers.label, config);
				break;
			case "test":
				config.print();
				dataHelpers.load_data(config.INPUT_DATA_PATH);
				if(config.USE_TPE)
				{
					System.out.println("Parsing corpus...");
					dataHelpers.load_parsed_corpus(config.PARSED_CORPUS_PATH);
				}
				System.out.println("Start testing!");
				bdr_extractor.test(dataHelpers.index, dataHelpers.corpus
						, dataHelpers.parsed_corpus
						, dataHelpers.label, config);		
				break;
			/*case "10-fold":
				for(int i = 1 ; i <= 10 ; i ++)
				{
					//train
					config.USE_TPE = true;
					config.USE_MDEX = true;
					
					dataHelpers = new DataHelpers();					
					config.INPUT_DATA_PATH = "input/10-fold/fold"+i+"_train.txt";
					config.OUTPUT_RESULT_PATH = "output/10-fold/fold"+i+"_train";
					config.PARSED_CORPUS_PATH = config.OUTPUT_RESULT_PATH+".parse.txt";
					
					config.OUTPUT_RESULT_PATH += ".comb.txt";
					
					config.CONFIDENCE_PATH = "resource/confidence_fold"+i+"_train.json";
					config.print();
					
					dataHelpers.load_data(config.INPUT_DATA_PATH);
					System.out.println("Parsing corpus...");
					dataHelpers.load_parsed_corpus(config.PARSED_CORPUS_PATH, false);
					System.out.println("Start training!");
					
					bdr_extractor.train(dataHelpers.corpus, dataHelpers.parsed_corpus
							, dataHelpers.label, dataHelpers.binary_label
							, new ArrayList<Boolean>(), config);
					
					config.CONFIDENCE_PATH = "resource/confidence_fold"+i+"_train.json";
					//test
					Evaluator evaluator = new Evaluator();
					
					boolean[][] runningSet = {{true, true}, {true, false}, {false, true}};
					for(boolean[] running_option : runningSet)
					{
						config.USE_TPE = running_option[0];
						config.USE_MDEX = running_option[1];

						dataHelpers = new DataHelpers();
						config.INPUT_DATA_PATH = "input/10-fold/fold"+i+"_test.txt";
						config.OUTPUT_RESULT_PATH = "output/10-fold/fold"+i+"_test";
						config.EVALUATION_RESULT_PATH = "output/10-fold/fold"+i+"_eval";
						config.PARSED_CORPUS_PATH = config.OUTPUT_RESULT_PATH+".parse.txt";
						dataHelpers.load_data(config.INPUT_DATA_PATH);
						if(config.USE_TPE && config.USE_MDEX) {
							config.OUTPUT_RESULT_PATH += ".comb.txt";
							config.EVALUATION_RESULT_PATH += ".comb.txt";
						}
						else if(!config.USE_TPE && config.USE_MDEX) {
							config.OUTPUT_RESULT_PATH += ".mdex.txt";
							config.EVALUATION_RESULT_PATH += ".mdex.txt";
						}							
						else if(config.USE_TPE && !config.USE_MDEX) {
							config.OUTPUT_RESULT_PATH += ".tpe.txt";
							config.EVALUATION_RESULT_PATH += ".tpe.txt";
						}					
						
						System.out.println("Parsing corpus...");
						dataHelpers.load_parsed_corpus(config.PARSED_CORPUS_PATH, true);
						System.out.println("Start testing!");
						bdr_extractor.test(dataHelpers.index, dataHelpers.corpus
								, dataHelpers.parsed_corpus
								, dataHelpers.is_contain_relation, config);
						evaluator.run(config.INPUT_DATA_PATH, config.OUTPUT_RESULT_PATH, config.EVALUATION_RESULT_PATH);
					}
				}
				break;*/
/*			case "eval":
				Evaluator evaluator = new Evaluator();
				evaluator.run(config.INPUT_DATA_PATH, config.OUTPUT_RESULT_PATH);
				break;
			case "10-fold evaluation":
				String tmp_output = config.OUTPUT_RESULT_PATH;
				for(int i = 1 ; i <= 10 ; i++)
				{
					evaluator = new Evaluator();
					dataHelpers = new DataHelpers();					
					boolean[][] runningSet = {{true, true}, {true, false}, {false, true}};
					for(boolean[] running_option : runningSet)
					{
						config.USE_TPE = running_option[0];
						config.USE_MDEX = running_option[1];

						dataHelpers = new DataHelpers();
						config.OUTPUT_RESULT_PATH = tmp_output.replace("fold1", "fold"+i);
						
						dataHelpers.load_data(config.INPUT_DATA_PATH);
						evaluator.run(config.INPUT_DATA_PATH, config.OUTPUT_RESULT_PATH);
					}
				}*/
			}
			
			long end_time = System.currentTimeMillis();
			LOG.info("Total process run time: "+(end_time - start_time)/1000+"s");
	}
	
	private static Configure parsingCommand(String[] args) throws ParseException
	{
		options = setOption();
		
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd = parser.parse(options, args);
		
		Configure config = new Configure(getOption(cmd,"c",true));
		String input_path = getOption(cmd, "i", false);
		String output_path = getOption(cmd, "o", false);
		
		config.INPUT_DATA_PATH = input_path;
		config.OUTPUT_RESULT_PATH = output_path;
		config.PARSED_CORPUS_PATH = output_path+".parsed.txt";
		
		if(getOption(cmd, "pt", false) != null) {
			config.PARSED_CORPUS_PATH = getOption(cmd, "pt", false);
		}
		
		return config;
	}
	
	private static String getOption(CommandLine cmd, String opt, boolean isRequirement)
	{
		HelpFormatter formatter = new HelpFormatter();
		if(cmd.hasOption(opt))
			return cmd.getOptionValue(opt);
		else if(isRequirement)
		{
			formatter.printHelp(USAGE_MSG, options);
			System.exit(0);
		}
		return null;
	}
	
	private static Options setOption()
	{
		Options options = new Options();
		
		Option config = new Option("c","configure",true,"The configuration file."); 
		config.setRequired(true);
		options.addOption(config);
		
		Option input = new Option("i", "input", true, "The input file (answer file for evaluation).");
		input.setRequired(true);
		options.addOption(input);
		
		Option output = new Option("o", "output", true, "The output file (predicted file for evaluation).");
		output.setRequired(true);
		options.addOption(output);
		
		Option parsed_tree = new Option("pt", "parsed_tree", true, "The parsed tree file");
		parsed_tree.setRequired(false);
		options.addOption(parsed_tree);
		
		return options;	
	}
	
	public static String get_file_name()
	{
		try {
			return new File(RelationExtractor_main.class.getProtectionDomain().getCodeSource().getLocation()
				    .toURI()).getPath();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
