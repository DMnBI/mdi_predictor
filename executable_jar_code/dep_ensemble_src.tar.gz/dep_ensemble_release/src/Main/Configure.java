package Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.Properties;

public class Configure {
	public static String DIRECTORY_PATH;

	public static String MODE;
	public static boolean USE_TPE;
	public static boolean USE_MDEX;
	
	public static String PROGRAM_DIR_PATH;

	public static String INPUT_DATA_PATH;
	public static String OUTPUT_RESULT_PATH;

	public static String SUB_RELATION_LIST_PATH;
	public static String SAMELEVEL_RELATION_LIST_PATH;
	public static String TPE_PATTERN_PATH;

	public static String PARSED_CORPUS_PATH;
	public static boolean PARSED_CORPUS_RESET;
	
	public static boolean USE_SVM_FILTER;
	public static String SVM_FILTER_DIR;
	public static Double SVM_FILTER_THRESHOLD;

	public static String CONFIDENCE_PATH;
	public static double CONFIDENCE_THRESHOLD;

//	public static String EVALUATION_RESULT_PATH;
	
	public Configure(String config_path) {
		// Read options(arguments)
		Properties options = new Properties();
		InputStream input;

		try {
			input = new FileInputStream(config_path);
			options.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		this.DIRECTORY_PATH = get_directory_path();
		
		this.MODE = options.getProperty("MODE");
		this.USE_TPE = Boolean.parseBoolean(options.getProperty("USE_TPE"));
		this.USE_MDEX = Boolean.parseBoolean(options.getProperty("USE_DBE"));
		this.INPUT_DATA_PATH = options.getProperty("INPUT_DATA_PATH");
		this.OUTPUT_RESULT_PATH = options.getProperty("OUTPUT_RESULT_PATH");

		this.DIRECTORY_PATH = options.getProperty("DBI_DIRECTORY");
		if(!this.DIRECTORY_PATH.endsWith("/"))
			this.DIRECTORY_PATH+="/";
		
		this.SUB_RELATION_LIST_PATH = DIRECTORY_PATH + options.getProperty("SUB_RELATION_LIST_PATH");
		this.SAMELEVEL_RELATION_LIST_PATH = DIRECTORY_PATH + options.getProperty("SAMELEVEL_RELATION_LIST_PATH");

		this.TPE_PATTERN_PATH = DIRECTORY_PATH + options.getProperty("TPE_PATTERN_PATH");

		this.PARSED_CORPUS_PATH = DIRECTORY_PATH + options.getProperty("PARSED_CORPUS_PATH");

		this.CONFIDENCE_PATH = DIRECTORY_PATH + options.getProperty("CONFIDENCE_PATH");
		this.CONFIDENCE_THRESHOLD = Double.parseDouble(options.getProperty("CONFIDENCE_THRESHOLD"));
	}

	public void print()
	{
		System.out.println("MODE = " + this.MODE);
		System.out.println("USE_TPE = " + this.USE_TPE);
		System.out.println("USE_DBE = " + this.USE_MDEX);
		System.out.println("INPUT_DATA_PATH = " + this.INPUT_DATA_PATH);
		System.out.println("OUTPUT_RESULT_PATH = " + this.OUTPUT_RESULT_PATH);
		System.out.println("DBI_DIRECTORY = " + this.DIRECTORY_PATH);
		System.out.println("SUB_RELATION_LIST_PATH = " + this.SUB_RELATION_LIST_PATH);
		System.out.println("TPE_PATTERN_PATH = " + this.TPE_PATTERN_PATH);
		System.out.println("PARSED_CORPUS_PATH = " + this.PARSED_CORPUS_PATH);
		System.out.println("CONFIDENCE_PATH = " + this.CONFIDENCE_PATH);
		System.out.println("CONFIDENCE_THRESHOLD = " + this.CONFIDENCE_THRESHOLD);
//		System.out.println("EVALUATION_RESULT_PATH = " + this.EVALUATION_RESULT_PATH);
	}
	
	public String get_directory_path() {
		try {
			return new File(Configure.class.getProtectionDomain().getCodeSource().getLocation()
				    .toURI()).getAbsolutePath().replaceAll("\\w+(.jar)", "");
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
