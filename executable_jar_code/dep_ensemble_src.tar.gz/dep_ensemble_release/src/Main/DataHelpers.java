package Main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import TPE.Parser;

public class DataHelpers {
	
	private final static Logger LOG = Logger.getGlobal();
	
	public List<String> index;
	public List<String> corpus;
	public List<String> parsed_corpus;
	public List<String> label;
	public List<Boolean> is_contain_relation;
	
	public Parser tpe_parser;
	
	public DataHelpers()
	{
		this.index = new ArrayList<>();
		this.corpus = new ArrayList<>();
		this.parsed_corpus = new ArrayList<>();
		this.label = new ArrayList<>();
		
		this.tpe_parser = new Parser();
	}
	
	public void load_data(String data_path)
	{
		LOG.info("load input data");
		
		String eachline;
		BufferedReader br;
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(data_path), "UTF-8"));
			while((eachline = br.readLine()) != null)
			{
				/*
				 * data[0]: index(integer)
				 * data[1]: tagged_sentence(string)
				 * data[2]: label(string) (DIS&BAC&relation, BAC&DIS&relation, true or false)
				 * */
				String[] data = eachline.split("\t");
				this.index.add(data[0].trim());
				this.corpus.add(data[1]);
				
				if(data.length >= 3)
					this.label.add(data[2]);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void load_parsed_corpus(String parsed_corpus_path)
	{
		File parsed_corpus_file = new File(parsed_corpus_path);
		try {
			if(parsed_corpus_file.exists())
			{
				BufferedReader br = new BufferedReader
						(new FileReader(parsed_corpus_path));
				String parsed_sentence;
				while((parsed_sentence = br.readLine()) != null)
				{
//					System.out.println(parsed_sentence);
					this.parsed_corpus.add(parsed_sentence);
				}
				br.close();
			}
			else
			{
				this.parsed_corpus = new ArrayList<>();
				BufferedWriter bw;
				
				bw = new BufferedWriter
						(new FileWriter(parsed_corpus_file));
				
				for(int i = 0 ; i < this.corpus.size() ; i++)
				{
					String sentence = this.corpus.get(i);
					if(sentence.contains("BAC00") && sentence.contains("DIS00"))
					{
						String tree = this.tpe_parser.makeParseTree(sentence);
						this.parsed_corpus.add(tree);
						bw.write(tree);
						bw.newLine();
					}
				}
				bw.flush();
				bw.close();		
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
