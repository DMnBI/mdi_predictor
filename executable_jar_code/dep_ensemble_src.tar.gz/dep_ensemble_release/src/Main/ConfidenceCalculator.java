package Main;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import utils.Stemmer;
import utils.Pair;
import utils.Triplet;

public class ConfidenceCalculator {
	Stemmer stemmer;
	JSONParser json_parser;
	Map<Integer, Map<String, Object>> confidence_table;
	
	public ConfidenceCalculator() {
		stemmer = new Stemmer();
		json_parser = new JSONParser();
		confidence_table = new HashMap<>();
	}
	
	public void build_confidence_table
		(List<List<Pair<Triplet, Integer>>> extracted_relation
		, List<String> label)
	{
		for(int index = 0 ; index < extracted_relation.size() ; index ++)
		{
			List<Pair<Triplet, Integer>> relations = extracted_relation.get(index);
			String results = label.get(index);
			
			if(relations.size() == 0)
				continue;
			
			for(Pair<Triplet, Integer> relation : relations)
			{
				String original_relation = relation.getFirst().relation;
				String relation_word = get_stemed_relation(original_relation);
				int pattern_index = relation.getSecond();
//				System.out.println(relation_word+", "+pattern_index);
				
				if(!confidence_table.containsKey(pattern_index))
				{
					Map<String, Object> pattern_info = new HashMap<>();
					Map<String, Object> true_word = new HashMap<>();
					Map<String, Object> false_word = new HashMap<>();
					
					pattern_info.put("tp", 0);
					pattern_info.put("fp", 0);
					pattern_info.put("true_word", true_word);
					pattern_info.put("false_word", false_word);
					
					this.confidence_table.put(pattern_index, pattern_info);
				}
				
				boolean correct = false;
				for(String l : results.split(","))
				{
					if(l.equals("None"))
						break;
					else if(l.split("&")[2].equalsIgnoreCase(original_relation))
						correct = true;
				}
				String word_correct, is_positive;
				if(correct)
				{
					word_correct = "true_word";
					is_positive = "tp";
				}
				else
				{
					word_correct = "false_word";
					is_positive = "fp";
				}
				Map<String, Object> pattern_info = this.confidence_table.get(pattern_index);
				Map<String, Integer> word_count = (Map<String, Integer>) pattern_info.get(word_correct);
				
				if(word_count.containsKey(relation_word))
					word_count.replace(relation_word, word_count.get(relation_word) + 1);
				else
					word_count.put(relation_word, 1);
				
				pattern_info.replace(is_positive, (Integer)pattern_info.get(is_positive) + 1);
			}
		}
	}
	
	public List<Pair<Triplet, Double>> confidence_filtering(
			List<Pair<Triplet, Integer>> candidate,
			Double confidencec_threshold)
	{
		List<Pair<Triplet, Double>> final_candidate = new ArrayList<>();
		double eps = 1e-3;
		
		for(int i = 0 ; i < candidate.size() ; i++)
		{
			String original_relation = candidate.get(i).getFirst().relation;
			String relation_word = get_stemed_relation(original_relation);
			
			int pattern_index = candidate.get(i).getSecond();
			double prob_cond_p_w;
            
			// trained (known) Patterns
			if (this.confidence_table.containsKey(pattern_index)) {
                Map<String, Object> patternInfo = this.confidence_table.get(pattern_index);

                double prob_p = (double) patternInfo.get("precision");
                double prob_cond_w_p, prob_cond_w_not_p;

                double tp = (int) patternInfo.get("tp");
                double fp = (int) patternInfo.get("fp");
                Map<String, Integer> true_word = (Map<String, Integer>) patternInfo.get("true_word");
                Map<String, Integer> false_word = (Map<String, Integer>) patternInfo.get("false_word");

                if (true_word.containsKey(relation_word))
                    prob_cond_w_p = true_word.get(relation_word) / tp;
                else
                    prob_cond_w_p = eps;

                if (false_word.containsKey(relation_word))
                    prob_cond_w_not_p = false_word.get(relation_word) / fp;
                else
                    prob_cond_w_not_p = eps;

                prob_cond_p_w = prob_cond_w_p * prob_p / (prob_cond_w_p * prob_p + prob_cond_w_not_p * (1 - prob_p));
            }
            // untrained (unknown) Patterns
            else {
                prob_cond_p_w = eps;
            }
            final_candidate.add(new Pair<>(candidate.get(i).getFirst(), prob_cond_p_w));
		}
		
		List<Pair<Triplet, Double>> tempRelationWord = new ArrayList<>();
        for (Pair<Triplet, Double> word : final_candidate) {
            if (confidencec_threshold <= word.getSecond()) {
                tempRelationWord.add(word);
            }
        }
        tempRelationWord.sort(Comparator.comparing(Pair::getSecond));
        Collections.reverse(tempRelationWord);

        // remove duplicated words
        Set<String> uniqueTriplets = new HashSet<>();
        List<Pair<Triplet, Double>> finalRelationWord = new ArrayList<>();
        for (Pair<Triplet, Double> t : tempRelationWord) {
            String key = t.getFirst().entity1 + t.getFirst().entity2;
            if (!uniqueTriplets.contains(key)) {
                uniqueTriplets.add(key);
                finalRelationWord.add(t);
            }
        }

        return finalRelationWord;
	}
	
	public void save_confidence(String CONFIDENCE_PATH) {
        JSONObject obj = new JSONObject();
        for (Map.Entry<Integer, Map<String, Object>> pattern : this.confidence_table.entrySet()) {
            JSONObject info = new JSONObject();
            int tp = (int) pattern.getValue().get("tp");
            int fp = (int) pattern.getValue().get("fp");
            info.put("tp", tp);
            info.put("fp", fp);
            info.put("precision", (double) tp / (tp + fp));

            JSONObject true_word = new JSONObject();
            for (Map.Entry<String, Integer> word : ((Map<String, Integer>) pattern.getValue().get("true_word")).entrySet()) {
                true_word.put(word.getKey(), word.getValue());
            }
            info.put("true_word", true_word);

            JSONObject false_word = new JSONObject();
            for (Map.Entry<String, Integer> word : ((Map<String, Integer>) pattern.getValue().get("false_word")).entrySet()) {
                false_word.put(word.getKey(), word.getValue());
            }
            info.put("false_word", false_word);

            obj.put(pattern.getKey(), info);
        }
        try (FileWriter file = new FileWriter(CONFIDENCE_PATH)) {
            file.write(obj.toJSONString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void load_confidence(String CONFIDENCE_PATH) {
        try {
            JSONObject obj = (JSONObject) json_parser.parse(new FileReader(CONFIDENCE_PATH));
            for (Map.Entry<Integer, Map<String, Object>> pattern : ((Map<Integer, Map<String, Object>>) obj).entrySet()) {
                Map<String, Object> patternInfo = new HashMap<>();
                patternInfo.put("precision", Double.parseDouble(String.valueOf(pattern.getValue().get("precision"))));
                patternInfo.put("tp", Integer.parseInt(String.valueOf(pattern.getValue().get("tp"))));
                patternInfo.put("fp", Integer.parseInt(String.valueOf(pattern.getValue().get("fp"))));
                Map<String, Integer> true_word = new HashMap<>();
                Map<String, Integer> false_word = new HashMap<>();
                for (Map.Entry<String, Integer> word : ((Map<String, Integer>) pattern.getValue().get("true_word")).entrySet()) {
                    true_word.put(word.getKey(), Integer.parseInt(String.valueOf(word.getValue())));
                }
                patternInfo.put("true_word", true_word);
                for (Map.Entry<String, Integer> word : ((Map<String, Integer>) pattern.getValue().get("false_word")).entrySet()) {
                    false_word.put(word.getKey(), Integer.parseInt(String.valueOf(word.getValue())));
                }
                patternInfo.put("false_word", false_word);

                this.confidence_table.put(Integer.parseInt(String.valueOf(pattern.getKey())), patternInfo);
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }
    
	public String get_stemed_relation(String relation)
	{
		String[] splited_relation = relation.split("_");
		String last_word = splited_relation[splited_relation.length - 1];
		
		last_word = stemmer.getStem(last_word);
		return last_word;
	}
}
