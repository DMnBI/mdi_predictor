package Bacteria;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;

import DBNER.NER.Tagger;

public class BacteriaSearcher {
	public static ArrayList<String> bacteriaList;
	public static ArrayList<String> bacteria_abbr_list;
	private static String listName = "data/bacteria_list.txt";
	
	public BacteriaSearcher()
	{
		listName = get_directory_path()+listName;
		bacteriaList = new ArrayList<>();
		bacteria_abbr_list = new ArrayList<>();
		loadBacteriaList();		
	}
	public String getBacteriaName(String bact) {
		
		bact = bact.replace("0", "."); //Match로 수정 
		String term;
		for(int index = 0 ; index < bacteria_abbr_list.size() ; index++)
		{
			term = bacteriaList.get(index);
			if(bact.toLowerCase().contains(term.toLowerCase()))
			{
				return term;
			}
			term = bacteria_abbr_list.get(index);
			if(bact.toLowerCase().contains(term.toLowerCase()) && !term.equals(""))
			{
				return bacteriaList.get(index);
			}
		}
		return "";
	}
	private void loadBacteriaList()
	{
		try {
			
		String execPath = BacteriaSearcher.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
	    File bacteriaListFile = new File(listName);
		BufferedReader listReader = new BufferedReader(new FileReader(bacteriaListFile));
		String eachline;
		
		while((eachline = listReader.readLine()) != null)
		{
			String[] bacteria = eachline.split("\t");
			if(bacteria[0]!=null)
				bacteriaList.add(bacteria[0]);
			else
				bacteriaList.add("");
			if(bacteria.length >= 2)
				bacteria_abbr_list.add(bacteria[1]);
			else
				bacteria_abbr_list.add("");
		}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 
	
	public String get_directory_path() {
		try {
			return new File(BacteriaSearcher.class.getProtectionDomain().getCodeSource().getLocation()
				    .toURI()).getAbsolutePath().replaceAll("\\w+(.jar)", "");
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
