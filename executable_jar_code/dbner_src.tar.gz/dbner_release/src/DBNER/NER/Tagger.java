package DBNER.NER;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Bacteria.BacteriaSearcher;
import DBNER.Data.Annotation;
import DBNER.Data.Literature;

public class Tagger {

	private static String STRAIN_LIST = "data/strain_list.txt";
	private static String VIRUS_LIST = "data/virus_list.txt";
	
	private String exec_path;
	
	private ArrayList<String> bacteria_list;
	private ArrayList<String> bacteria_abbr_list;
	private ArrayList<String> strain_list;
	private ArrayList<String> virus_list;
	
	public Tagger()
	{
		STRAIN_LIST = get_directory_path() + STRAIN_LIST;
		VIRUS_LIST = get_directory_path() + VIRUS_LIST;
		
		bacteria_list = BacteriaSearcher.bacteriaList;
		bacteria_abbr_list = BacteriaSearcher.bacteria_abbr_list;
		strain_list = new ArrayList<>();
		virus_list = new ArrayList<>();
		loadDictionary();
	}
	
	public ArrayList<Annotation> annotate(Literature literature)
	{
		String content = literature.getContent();
		content = " "+content.trim()+" ";
		ArrayList<Annotation> annotList = new ArrayList<Annotation>();
		annotList.addAll(annotateByString(literature, BacteriaSearcher.bacteriaList, "Bacteria"));
//		annotList.addAll(annotateByString(literature, BacteriaSearcher.bacteria_abbr_list, "Bacteria"));
		annotList.addAll(annotateByRegex(literature, strain_list, "Strain"));
		annotList.addAll(annotateByString(literature, virus_list, "Virus"));
		
		return annotList;
	}
	public String getBacteriaName(String bact) {
		
		bact = bact.replace("0", "."); //Match로 수정 
		String term;
		for(int index = 0 ; index < bacteria_abbr_list.size() ; index++)
		{
			term = bacteria_list.get(index);
			if(bact.toLowerCase().contains(term.toLowerCase()))
			{
				return term;
			}
			term = bacteria_abbr_list.get(index);
			if(bact.toLowerCase().contains(term.toLowerCase()) && !term.equals(""))
			{
				return bacteria_list.get(index);
			}
		}
		return "";
	}
	
	public ArrayList<Annotation> annotateByRegex(Literature literature,
			ArrayList<String> regex_list, String type)
	{
		ArrayList<Annotation> annotation_list = new ArrayList<>();
		
		String content = literature.getContent();
		
		for(String regex : regex_list)
		{
			String pattern = "(\\s|$)"+regex;
			Pattern p = Pattern.compile(pattern);
			Matcher m = p.matcher(content);
			annotation_list.addAll(getEntitiesByPattern(literature, m, type, null));
		}
		return annotation_list;
	}
	public ArrayList<Annotation> annotateByString(Literature literature
			, ArrayList<String> dictionary, String type)
	{ //dictionary 기반 태깅
		ArrayList<Annotation> annotation_list = new ArrayList<>();
		
		String pmid = literature.getPMID();
		String title = literature.getTitle();
		String content = literature.getContent();
		
		for(String dic : dictionary)
		{			
			if(dic.equals(""))
				continue;
			String pattern = Tagger.getPattern(dic);
			Pattern p = Pattern.compile(pattern);
			Matcher m = p.matcher(content);
			ArrayList<Annotation> anno_result = getEntitiesByPattern(literature, m, type, null);
			annotation_list.addAll(anno_result);
			
			if(anno_result.size() == 0)
				continue;
			
			String genus = dic.split("\\s+")[0];
			for(int index = 1 ; index < genus.length()-1 && dic.split("\\s+").length >= 2
					&& type == "Bacteria" ; index ++)
			{
				pattern = "(?-i)"+genus.substring(0, index)+"." + dic.replace(genus, "");
				p = Pattern.compile(pattern);
				m = p.matcher(content);
				annotation_list.addAll(getEntitiesByPattern(literature, m, type, anno_result.get(0).name));
			}
		}
		return annotation_list;
	}
	private ArrayList<Annotation> getEntitiesByPattern(Literature literature,
			Matcher m, String type, String id)
	{
		ArrayList<Annotation> annotation_list = new ArrayList<Annotation>();

		String pmid = literature.getPMID();
		String title = literature.getTitle();
		
		while(m.find())
		{
			int start = m.start()+1;
			int end = m.end()+1;
			String name = m.group();
			
			while(!name.substring(0, 1).matches("[A-Za-z0-9\\.]"))
			{
				start++;
				name = name.substring(1);
			}
			while(!name.substring(name.length()-1).matches("[A-Za-z0-9]"))
			{
				if(name.trim().endsWith("sp.") || name.trim().endsWith("spp.")
						|| name.trim().endsWith("subsp.") || name.trim().endsWith("subspp.")
						|| name.trim().endsWith("str.") || name.trim().endsWith("substr.")){break;}
				end--;
				name = name.substring(0, name.length()-1);
			}
			Annotation new_anno;
			if(id == null)
				new_anno = new Annotation(pmid, start+title.length(), end+title.length(), name, type, name);
			else
				new_anno = new Annotation(pmid, start+title.length(), end+title.length(), name, type, id);
			annotation_list.add(new_anno);
		}
		return annotation_list;
	}
	
	private void loadDictionary()
	{
		System.out.println("Loading Dictionary");
		
		bacteria_list = new ArrayList<>();
		bacteria_abbr_list = new ArrayList<>();
		strain_list = new ArrayList<>();
		virus_list = new ArrayList<>();
		
		loadStrain();
		loadVirus();
	}
	
	private void loadVirus()
	{		
		virus_list = new ArrayList<>();

		try {
			
			File virus_list_file = new File(VIRUS_LIST);
			BufferedReader listReader = new BufferedReader(
					new FileReader(virus_list_file));
			String eachline;
			
			while((eachline = listReader.readLine()) != null)
			{
				virus_list.add(eachline);
			}
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void loadStrain()
	{
		try {
			
			File strain_list_file = new File(STRAIN_LIST);
			BufferedReader listReader = new BufferedReader(new FileReader(strain_list_file));
			String eachline;
			
			while((eachline = listReader.readLine()) != null)
			{
				strain_list.add(eachline);
			}
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	public static String getPattern(String entity)
	{
		Pattern p = Pattern.compile("[*]|[+]|[$]|[|]");
		entity = entity.replace(")", "\\)").replace("(", "\\(").replace("[", "\\[").replace("]", "\\]")
				.replace("^", "\\^").replace("{", "\\{").replace("}", "\\}").replace(".","\\.");
		entity = entity.replace("*", "[*]").replace("+", "[+]").replace("$", "[$]").replace("|", "[|]");
		entity = entity.replaceAll("\\s+", "\\\\s+");
		entity = "[^A-Za-z0-9-]?(?i)("+entity+")[^A-Za-z0-9]";
		return entity;
	}
	
	public String get_directory_path() {
		try {
			return new File(Tagger.class.getProtectionDomain().getCodeSource().getLocation()
				    .toURI()).getAbsolutePath().replaceAll("\\w+(.jar)", "");
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
