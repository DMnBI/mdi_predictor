package DBNER.Data;

import java.util.ArrayList;

public class Literature {
	private String pmid;
	private String title;
	private String content;
	private String annotatedContent;
	
	private ArrayList<Annotation> annotation_list;
	
	
	public Literature(String pmid, String title, String content, ArrayList<Annotation> anno_list)
	{
		this.pmid = pmid;
		this.title = title;
		this.content = content;
		annotation_list = anno_list;
	}
	public Literature() 
	{
		annotation_list = new ArrayList<Annotation>();
	}
	
	public void setPMID(String pmid) {this.pmid=pmid;}
	public void setTitle(String title) {this.title=title;}
	public void setContent(String content) {this.content=content+" ";}
	public void addAnnotation(ArrayList<Annotation> added_anno) 
	{
		for(Annotation anno : added_anno)
		{
			addAnnotation(anno);
		}
	}

	public void addAnnotation(Annotation new_anno)
	{
		if(new_anno != null)
			this.annotation_list.add(new_anno);
	}
	
	public String getPMID() {return pmid;}
	public String getTitle() {return title;}
	public String getContent() {return content;}
	public ArrayList<Annotation> getAnnotationList(){return annotation_list;}
	private void sortMergeList()
	{
		SortingAnnotations_Quick quicksort = new SortingAnnotations_Quick();
		if(annotation_list.size() >= 2)
			annotation_list = quicksort.sort(annotation_list.toArray(new Annotation[0]));
	}
	
	public void mergeBacNStr()
	{
		ArrayList<Annotation> new_entity_list = new ArrayList<Annotation>();
		Annotation prev_anno = null;
		
		sortMergeList();
		for(Annotation curr_anno : annotation_list)
		{
			if(Integer.parseInt(curr_anno.getStart()) <= title.length())
				continue;
			if(curr_anno.type.equals("Disease") || curr_anno.type.equals("Virus")) {
				new_entity_list.add(curr_anno);
				continue;	
			}
			if(prev_anno == null)
			{
				prev_anno = curr_anno;
				continue;
			}
			else
			{
				ArrayList<Annotation> mergedAnnotation = mergeAnnotation(prev_anno, curr_anno);
				prev_anno = mergedAnnotation.get(mergedAnnotation.size()-1);
				mergedAnnotation.remove(mergedAnnotation.size()-1);
				for(Annotation anno : mergedAnnotation)
					new_entity_list.add(anno);
			}
		}
		if(prev_anno != null)
			new_entity_list.add(prev_anno);
		annotation_list = new_entity_list;
		
	}
	public void removeDuplicates()
	{
		ArrayList<Annotation> new_entity_list = new ArrayList<Annotation>();
		Annotation prev_anno = null;
		
		sortMergeList();
		for(Annotation curr_anno : annotation_list)
		{		
			if(curr_anno == null)
				continue;
			if(Integer.parseInt(curr_anno.getStart()) <= title.length())
				continue;
			if(prev_anno == null)
			{
				prev_anno = curr_anno;
				continue;
			}
			else
			{
				ArrayList<Annotation> mergedAnnotation = mergeAnnotation(prev_anno, curr_anno);
				prev_anno = mergedAnnotation.get(mergedAnnotation.size()-1);
				mergedAnnotation.remove(mergedAnnotation.size()-1);
				if(mergedAnnotation.size() >= 1)
					new_entity_list.add(mergedAnnotation.get(0));
			}
		}
		if(prev_anno != null)
			new_entity_list.add(prev_anno);
		annotation_list = new_entity_list;
	}
	public ArrayList<Annotation> mergeAnnotation(Annotation prev_anno, Annotation curr_anno)
	{
		int prev_start, prev_end;
		int curr_start, curr_end;
		String id = null;
		
		prev_start = Integer.parseInt(prev_anno.getStart());
		prev_end = Integer.parseInt(prev_anno.getEnd());
		curr_start = Integer.parseInt(curr_anno.getStart());
		curr_end = Integer.parseInt(curr_anno.getEnd());
		
		ArrayList<Annotation> annotations = new ArrayList<Annotation>();
		String type = null;
		if(prev_end+1 < curr_start)
		{
			annotations.add(prev_anno);
			annotations.add(curr_anno);
			return annotations;
		}
		else if(prev_end == curr_end)
		{
			type = getTypeByPriority(prev_anno.getType(), curr_anno.getType());
			if(type.equals(prev_anno.getType()))
				id = prev_anno.id;
			else
				id = curr_anno.id;
		}
		else if(prev_anno.getType().equals("Strain"))
		{
			if(curr_anno.getType().equals("Bacteria"))
			{
				type = "Bacteria";
				id = curr_anno.id;
			}
			else 
			{
				annotations.add(curr_anno);
				return annotations;
			}
		}
		else if(curr_anno.getType().equals("Strain"))
		{
			if(prev_anno.getType().equals("Bacteria"))
			{
				type = "Bacteria";
				id = prev_anno.id;
			}
			else
			{
				annotations.add(prev_anno);
				return annotations;
			}		
			
		}
		else if(prev_end > curr_end)
		{
			type = prev_anno.getType();
			id = prev_anno.getId();
		}
		else 
		{
			type = curr_anno.getType();
			id = curr_anno.getId();
		}
		
		int new_start = getSmallNum(prev_start, curr_start);
		int new_end = getBigNum(prev_end, curr_end);
		
		String name = content.substring(new_start-title.length()-1
				, new_end-title.length()-1);
		annotations.add(new Annotation(pmid, new_start, new_end, name, type, id));
		return annotations;
	}
	
	
	public String getTypeByPriority(String prev_type, String curr_type) 
	{
		String type;
		if(prev_type.equals("Virus")
				|| curr_type.equals("Virus"))
			type = "Virus";
		else if(prev_type.equals("Bacteria")
				|| curr_type.equals("Bacteria"))
			type = "Bacteria";
		else if(prev_type.equals("Disease")
				|| curr_type.equals("Disease"))
			type = "Disease";
		else if(prev_type.equals("Strain")
				|| curr_type.equals("Strain"))
			type = "Strain";
		else
			type = "";
		return type;
	}
	/*public void removingDuplicates()
	{
		sortMergeList();
		System.out.println("remove duplicates");
		
		ArrayList<Annotation> new_entity_list = new ArrayList<Annotation>();
		
		Annotation prev_entity = null;
		int prev_start, prev_end;
		int curr_start, curr_end;
		
		for(Annotation entity : annotation_list)
		{
//			System.out.println(">>"+entity.getName());
			if(Integer.parseInt(entity.getStart()) <= title.length())
				continue;
			
			Annotation new_entity = null;
			
			if(prev_entity == null)
			{
				prev_entity = entity;
				continue;
			}
			
			prev_start = Integer.parseInt(prev_entity.getStart());
			prev_end = Integer.parseInt(prev_entity.getEnd());
			curr_start = Integer.parseInt(entity.getStart());
			curr_end = Integer.parseInt(entity.getEnd());
			
			String type;			
			if(prev_end < curr_start)
			{
				if(!prev_entity.getType().equals("Strain") &&
						!prev_entity.getType().equals("Virus") )
					new_entity_list.add(prev_entity);
				prev_entity = entity;
				continue;
			}
			else if(prev_end == curr_end)
			{
				if(prev_entity.getType().equals("Virus")
						|| entity.getType().equals("Virus"))
					type = "Virus";
				else if(prev_entity.getType().equals("Bacteria")
						|| entity.getType().equals("Bacteria"))
					type = "Bacteria";
				else if(prev_entity.getType().equals("Disease")
						|| entity.getType().equals("Disease"))
					type = "Disease";
				else if(prev_entity.getType().equals("Strain")
						|| entity.getType().equals("Strain"))
					type = "Strain";
				else
					type = "";
			}
			else
			{
				if(prev_entity.getType().equals("Bacteria") && entity.getType().equals("Strain"))
				{
					int nPrev_entity_endpoint = Integer.parseInt(entity.start)-1;
					prev_entity.name = prev_entity.name.substring(0, nPrev_entity_endpoint - Integer.parseInt(prev_entity.start));
					prev_entity.end = String.valueOf(nPrev_entity_endpoint);
					
					new_entity_list.add(prev_entity);
					prev_entity = entity;
					continue;
				}
				else if(prev_entity.getType().equals("Strain"))
				{
					prev_entity = entity;
					continue;
				}					
				else if(entity.getType().equals("Strain"))
					continue;
				else if(prev_end > curr_end)
					type = prev_entity.getType();
				else
					type = entity.getType();				
			}
			
			int new_start = getSmallNum(prev_start, curr_start);
			int new_end = getBigNum(prev_end, curr_end);
			
			String name = content.substring(new_start-title.length()-1
					, new_end-title.length()-1);
			new_entity = new Annotation(pmid, new_start, new_end, name, type);
			prev_entity = new_entity;
		}
		if(prev_entity != null)
		{
			if(!prev_entity.getType().equals("Strain") &&
				!prev_entity.getType().equals("Virus") )
				new_entity_list.add(prev_entity);
		}
		
		annotation_list = new_entity_list;
	}*/
	
	public static int getSmallNum(int num1, int num2)
	{
		if(num1 <= num2)
			return num1;
		else
			return num2;
	}
	
	public static int getBigNum(int num1, int num2)
	{
		if(num1 >= num2)
			return num1;
		else
			return num2;
	}
}
