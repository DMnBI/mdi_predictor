package DBNER.Data;

public class Annotation {
	private String pmid;
	
	public String start;
	public String end;
	public String name;
	public String type;
	public String id;
	
	
	public Annotation(String pmid, String start, String end, String name, String type, String id)
	{
		this.pmid = pmid;
		this.start = start;
		this.end = end;
		this.name = name;
		this.type = type;
		this.id = id;		
	}
	
	public Annotation(String pmid, int start, int end, String name, String type, String id)
	{
		this.pmid = pmid;
		this.start = String.valueOf(start);
		this.end = String.valueOf(end);
		this.name = name;
		this.type = type;
		this.id = id;		
	}
	
	public String getStart() {return start;}
	public String getEnd() {return end;}
	public String getName() {return name;}
	public String getType() {return type;}
	public String getId() {return id;}
}
