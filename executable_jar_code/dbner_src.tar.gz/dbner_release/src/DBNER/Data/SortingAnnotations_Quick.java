package DBNER.Data;

import java.util.ArrayList;

public class SortingAnnotations_Quick {
	private Annotation[] annotations;
	private int number;
	
	public ArrayList<Annotation> sort(Annotation[] annotations)
	{
		if(annotations == null || annotations.length == 0)
			return arrayToList(annotations);
		
		this.annotations = annotations;
		number = annotations.length;
		quicksort(0, number-1);
		
		return arrayToList(annotations);
	}
	
	private ArrayList<Annotation> arrayToList(Annotation[] annotations)
	{
		ArrayList<Annotation> tmpAnnotationList = new ArrayList<Annotation>();
		for(Annotation anno : annotations)
			tmpAnnotationList.add(anno);
		return tmpAnnotationList;
	}
	private void quicksort(int low, int high)
	{
		int i = low, j = high;
		Annotation pivot = annotations[low + (high-low)/2];

		while(i <= j) {
			int i_start = Integer.valueOf(annotations[i].getStart());
			int j_start = Integer.valueOf(annotations[j].getStart());
			int pivot_start = Integer.valueOf(pivot.getStart());
			while(i_start < pivot_start) 
			{
				i++;
				i_start = Integer.valueOf(annotations[i].getStart());
			}
			while(j_start > pivot_start)
			{
				j--;
				j_start = Integer.valueOf(annotations[j].getStart());
			}
			
			if(i <= j)
			{
				exchange(i, j);
				i++;
				j--;
			}
		}
		
		if(low < j)
			quicksort(low, j);
		if(i < high)
			quicksort(i, high);
	}
	
	private void exchange(int i, int j)
	{
		Annotation temp = annotations[i];
		annotations[i] = annotations[j];
		annotations[j] = temp;
	}
}
