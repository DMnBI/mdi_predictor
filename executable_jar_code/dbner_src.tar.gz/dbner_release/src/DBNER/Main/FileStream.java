package DBNER.Main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileStream {
		
	private static String pubtator_filename = ".tagged_abstracts.pubtator.txt";
	private static String sentence_filename = ".sentences.txt";
	private static String diseaseList_filename = ".disease.txt";
	private static String bacteriaList_filename = ".bacteria.txt";
	
	private static BufferedWriter pubtator_writer;
	private static BufferedWriter sentence_writer;
	private static BufferedWriter diseaseList_writer;
	private static BufferedWriter bacteriaList_writer;
	
	public static void setWriter(String output_path)
	{
		pubtator_writer = getWriter(output_path+pubtator_filename);
		sentence_writer = getWriter(output_path+sentence_filename);
		diseaseList_writer = getWriter(output_path+diseaseList_filename);
		bacteriaList_writer = getWriter(output_path+bacteriaList_filename);
	}
	public static BufferedWriter getPubtatorWriter()
	{
		return pubtator_writer;
	}
	public static BufferedWriter getSentenceWriter()
	{
		return sentence_writer;
	}
	public static BufferedWriter getDiseaseListWriter()
	{
		return diseaseList_writer;
	}
	public static BufferedWriter getBacteriaListWriter()
	{
		return bacteriaList_writer;
	}
	public static void closeWriter()
	{
		try {
			pubtator_writer.flush();
			pubtator_writer.close();
			sentence_writer.flush();
			sentence_writer.close();
			diseaseList_writer.flush();
			diseaseList_writer.close();
			bacteriaList_writer.flush();
			bacteriaList_writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String readFile(BufferedReader reader)
	{
		try {
			return reader.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}		
	}
	
	public static BufferedReader getReader(String file_path)
	{
		try {
			BufferedReader reader = new BufferedReader(
					new FileReader(new File(file_path)));
			return reader;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static BufferedWriter getWriter(String filepath)
	{
		try {
			BufferedWriter writer = new BufferedWriter(
					new FileWriter(new File(filepath)));
			return writer;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
