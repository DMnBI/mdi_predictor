package DBNER.Main;

import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.CoreAnnotations.PartOfSpeechAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TextAnnotation;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.simple.Sentence;

public class Chunker {
	
	StanfordCoreNLP pipeline;
	public Chunker()
	{
		Properties props = new Properties();
		props.setProperty("annotators", "tokenize,ssplit,pos,depparse");
		props.setProperty("tokenize.keepeol", "true");
		props.setProperty("tokenize.verbose", "true");
		
		pipeline = new StanfordCoreNLP(props);
	}
	
	
	public String run(String sentence)
	{
		String raw_sentence = sentence.replaceAll("(BAC|DIS|STR|VIR)00", "");
		List<CoreLabel> taggedToken_list = tokenize_sentence(sentence);
		List<CoreLabel> rawToken_list = tokenize_sentence(raw_sentence);
		
		String word, pos;
		String pre_word, pre_pos;
		String chunk;
		String chunked_sentence; 
		
		chunk = pre_word = pre_pos = "";
		chunked_sentence = "";
		for(int index = 0; index < taggedToken_list.size() ; index ++)
		{
			CoreLabel tagged_token = taggedToken_list.get(index);
			CoreLabel raw_token = rawToken_list.get(index);
			
			word = tagged_token.getString(TextAnnotation.class);
			pos = raw_token.getString(PartOfSpeechAnnotation.class);
			
			if(!isEffectiveDis(word, pos))
				word = word.replace("DIS00", "");
			
			if(bacteriaChunking(chunk, pre_word, word, pos) || phraseChunking(pre_word, pre_pos, word, pos))
				chunk = chunk(chunk, word);
			else
			{
				if(chunk != "")
				{
					chunk = reAnnotate(chunk, 1);
					chunked_sentence += " "+chunk;
				}
				chunk = word;
			}
			pre_word = word;
			pre_pos = pos;
		}
		chunk = reAnnotate(chunk, 1);
		chunked_sentence += " "+chunk;
		
		chunked_sentence = postprocess(chunked_sentence);		
		
		return chunked_sentence;
	}
	public String chunk(String chunk, String word)
	{
		if(chunk != "")
			chunk += "_";
		return chunk+word;
	}

	public boolean phraseChunking(String pre_word, String pre_pos, String word, String pos)
	{
		if(!sameTag(pre_word, word) && !sameTag(pre_word, "None"))
			return false;
		/*else if(sameTag(pre_word, "None") && sameTag(word, "None"))
			return false;*/
		if(pre_pos.equals("JJ"))
		{
			if(pos.equals("JJ") || pos.startsWith("NN"))
				return true;
			else if(isBacteria(word) || isDisease(word))
				return true;
		}
		return false;
	}
	public boolean bacteriaChunking(String chunk, String preword, String word, String pos)
	{
		if((isBacteria(chunk) || isStrain(chunk)) && !isEffectiveWord(word))
			return true;
		else if(isStrain(preword) && pos.startsWith("NN"))
			return true;
		return false;
	}
	public boolean isEffectiveDis(String word, String pos)
	{
		String[] non_effective = {"disease", "diseases", "syndrome", "disorder"};
		
		if(!isDisease(word))
			return false;
		if(!(pos.startsWith("NN") || pos.startsWith("VB"))
			|| word.matches("DIS00[A-Z0-9\\-]+"))
			return false;
		
		word = word.toLowerCase();
		for(String nE_Dis : non_effective)
		{
			if(word.toLowerCase().equals("dis00"+nE_Dis))
				return false;
		}
		return true;
	}
	
	public boolean isDisease(String word)
	{
		if(sameTag(word, "DIS00"))
			return true;
		return false;
	}
	
	public boolean isBacteria(String word)
	{
		if(sameTag(word, "BAC00"))
			return true;
		return false;
	}
	
	public boolean isStrain(String word)
	{
		if(sameTag(word, "STR00"))
			return true;
		return false;
	}
	public List<CoreLabel> tokenize_sentence(String sentence)
	{
		Annotation doc = new Annotation(sentence);
		pipeline.annotate(doc);
		return doc.get(CoreAnnotations.TokensAnnotation.class);
	}
	public boolean isEffectiveWord(String word)
	{
		if(word.matches("[a-z]?[A-Z0-9\\-]+[a-z]?") || word.matches("[a-z]"))
			return false;
		return true;
	}
	public String postprocess(String sentence)
	{
		sentence = sentence.replace("bac00", "BAC00");
		sentence = sentence.replace("dis00", "DIS00");
		sentence = sentence.replace("``", "\"");
		sentence = sentence.replace("''", "\"");
		sentence = sentence.replace(" .", ".");		
		sentence = sentence.replaceAll("\\.$", " .");
		sentence = sentence.replaceAll("\\s+", " ");
		sentence = regexChunker(sentence);
		
		Pattern p = Pattern.compile("(BAC|DIS|STR)00\\S+");
		Matcher m = p.matcher(sentence);
		while(m.find())
		{
			String entity = m.group().trim();
			String mod_entity = entity.replaceAll("[^A-z0-9\\-\\_\\s]", "0");
			sentence = sentence.replace(entity, mod_entity);
		}
		return sentence;
	}
	public String regexChunker(String sentence)
	{
		sentence = getRegexChunk(sentence, "(DIS|BAC)00\\S+\\s+(with|of)\\s+(DIS|BAC)00\\S+", 0);
		sentence = getRegexChunk(sentence, "BAC00\\S+\\s(STR00\\S+\\s)+", 0);
		sentence = getRegexChunk(sentence, "(STR00\\S+\\s)+BAC00\\S+", 1);
		sentence = getRegexChunk(sentence, "(DIS|BAC)00\\S+\\s(DIS|BAC)00\\S+", 1);
		sentence = sentence.replaceAll("(VIR|STR)00", "");
		return sentence;
	}
	public String getRegexChunk(String sentence, String regex, int tagPosition)
	{
		Pattern chunkPattern = Pattern.compile(regex);
		return getChunkedSentnece(sentence, chunkPattern, true, tagPosition);
	}
	
	private String getChunkedSentnece(String sentence, Pattern pattern, Boolean replace_tag, int tag_position)
	{
		Matcher match = pattern.matcher(sentence);
		String chunk, temp_word;
		
		while(match.find())
		{
			temp_word = match.group().trim();
			chunk = temp_word.replaceAll("\\s+", "_");
			if(replace_tag)
				chunk = reAnnotate(chunk, tag_position);
			sentence = sentence.replace(temp_word, chunk);
		}
		return sentence;
	}
	private String reAnnotate(String word, int getted_tag_position)
	{
		int dt_index = word.indexOf("DIS00");
		int bt_index = word.indexOf("BAC00");
		
		String tag = "";
		if(dt_index == -1)
		{
			if(getted_tag_position == 0)
				dt_index = 99999;
			else if(getted_tag_position == 1)
				dt_index = -1;
		}			
		if(bt_index == -1)
		{
			if(getted_tag_position == 0)
				bt_index = 99999;
			else if(getted_tag_position == 1)
				bt_index = -1;
		}
		
		word = word.replaceAll("(BAC|DIS)00", "");
		if((dt_index == 99999 || dt_index == -1) && (bt_index == 99999 || bt_index == -1))
			return word;
		else if(getted_tag_position == 0)
		{
			if(dt_index < bt_index)
				word = "DIS00"+word;
			else
				word = "BAC00"+word;
		}
		else if(getted_tag_position == 1)
		{
			if(dt_index > bt_index)
				word = "DIS00"+word;
			else
				word = "BAC00"+word;
		}
		/*System.out.println(word);
		if(word.contains("DIS00") || word.contains("BAC00"))
			word = word.replaceAll("[^A-Za-z0-9\\_\\-]", "0");
		System.out.println(word);*/
		
		return word;
	}
	private boolean sameTag(String word1, String word2)
	{
		if(getTag(word1).equals(getTag(word2)))
			return true;
		return false;
	}
	private String getTag(String pha)
	{
		if(pha.contains("DIS00"))
			return "DIS";
		else if(pha.contains("BAC00"))
			return "BAC";
		else if(pha.contains("VIR00"))
			return "VIR";
		else if(pha.contains("STR00"))
			return "STR";
		else
			return "None";
	}
}
