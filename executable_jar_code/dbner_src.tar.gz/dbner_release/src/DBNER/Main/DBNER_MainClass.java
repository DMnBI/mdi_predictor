package DBNER.Main;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import org.apache.commons.cli.ParseException;

import DBNER.Data.Annotation;
import DBNER.Data.Literature;

public class DBNER_MainClass {

	private static Configure configure;

	public static void main(String[] args) throws ParseException {
		double start_time, end_time;
		start_time = getCurrentTime();
		execNER(args[0], args[1]);
		
		end_time = getCurrentTime();
		System.out.println("!Running time: " + (end_time - start_time) + "s.");
	}
	
	public static void execNER(String input_path, String output_path)
	{
		Literature newLiterature;
		BufferedReader inputReader = FileStream.getReader(input_path);
		FileStream.setWriter(output_path);
		DBNER dbner = new DBNER();
		
		while((newLiterature = getAbstract(inputReader)) != null)
		{
			dbner.run(newLiterature);
		}
		FileStream.closeWriter();
	}
	
	public static Literature getAbstract(BufferedReader inputReader)
	{
		
		Literature literature = null;
		String eachline;
		while((eachline = FileStream.readFile(inputReader)) != null)
		{
			if(eachline.contains("|t|"))
			{
				literature = new Literature();
				literature.setPMID(eachline.split("\\|t\\|")[0].trim());
				literature.setTitle(eachline.split("\\|t\\|")[1]);
			}
			else if(eachline.contains("|a|"))
			{
				if(eachline.split("\\|a\\|").length >= 2) 
				{
					literature.setContent(eachline.split("\\|a\\|")[1]);
				}
			}
			else if(eachline.length() > 2)
			{
				Annotation new_Anno = getAnnotation(eachline);
				if(new_Anno != null)
					literature.addAnnotation(new_Anno);
			}
			else
			{
				break;
			}
		}
		return literature;
	}
	
	
	private static Annotation getAnnotation(String eachline)
	{
		String[] splitted_line = eachline.split("\t");
		
		if(splitted_line.length <= 5)
			return null;
		
		String anno_pmid = splitted_line[0];
		String start_point = splitted_line[1];
		String end_point = splitted_line[2];
		String anno_name = splitted_line[3];
		String anno_type = splitted_line[4];
		String id = splitted_line[5];
		
		if(Pattern.matches("[A-Z0-9]+", anno_name)
				|| !id.startsWith("MESH:D"))
			return null;
		
		Annotation new_Anno = new Annotation(anno_pmid, start_point
				, end_point, anno_name, anno_type, id);
		return new_Anno;
	}
	
	private static double getCurrentTime() {
		long time = System.currentTimeMillis();
		return (time / 1000.0);
	}
}
