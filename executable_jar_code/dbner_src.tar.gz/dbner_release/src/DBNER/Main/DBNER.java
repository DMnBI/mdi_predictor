package DBNER.Main;

import java.io.BufferedWriter;
import java.io.IOException;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Bacteria.BacteriaSearcher;
import DBNER.Data.Annotation;
import DBNER.Data.Literature;
import DBNER.NER.Tagger;

public class DBNER 
{
	Tagger tagger;
	BacteriaSearcher bacteriaSearcher;

	BufferedWriter sentence_writer;
	BufferedWriter pubtator_writer;

	public DBNER()
	{		
		bacteriaSearcher = new BacteriaSearcher();
		tagger = new Tagger();
		sentence_writer = FileStream.getSentenceWriter();
		pubtator_writer = FileStream.getPubtatorWriter();
	}
	
	public void run(Literature literature)
	{
		literature = annotate_literature(literature);
		if(literature != null)
		{
			write_PubTator(literature);
			write_TaggedSentence(literature);				
		}
	}	
	
	private Literature annotate_literature(Literature literature)
	{
		if(literature.getContent().equals(""))
			return null;
		literature.addAnnotation(tagger.annotate(literature));
		literature.mergeBacNStr();
		literature.removeDuplicates();
		
		return literature;
	}
	
	private void write_PubTator(Literature literature)
	{
		String pmid = literature.getPMID();
		String title = literature.getTitle();
		String content = literature.getContent();
		ArrayList<Annotation> annotation_list = literature.getAnnotationList();
		
		try {
			pubtator_writer.write(pmid+"|t|"+title);
			pubtator_writer.newLine();
			pubtator_writer.write(pmid+"|a|"+content);
			pubtator_writer.newLine();
			for(Annotation anno : annotation_list)
			{
				if(anno == null)
					continue;
				pubtator_writer.write(pmid+"\t"+anno.getStart()+"\t"+anno.getEnd()+"\t"
						+anno.getName()+"\t"+anno.getType()+"\t"+anno.getId());
				pubtator_writer.newLine();
			}
			pubtator_writer.newLine();
			pubtator_writer.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void write_TaggedSentence(Literature literature)
	{		
		System.out.println("write tagged sentence : "+literature.getPMID());
		ArrayList<String[]> annotated_result = getAnnotatedContent(literature); //0~n-1: tag info, n: content
		
		String content = annotated_result.get(annotated_result.size()-1)[0];
		ArrayList<String> taggedSentence_list = splitSentence(content.trim());
		ArrayList<String> rawSentence_list = splitSentence(literature.getContent());

		Chunker chunker = new Chunker();
		
		content="";
		
		int count = 1;
		for(int index = 0; index < rawSentence_list.size() 
				&& index < taggedSentence_list.size() ; index++)
		{
			String tagged_sentence = taggedSentence_list.get(index);
			String raw_sentence = rawSentence_list.get(index);
			tagged_sentence = chunker.run(tagged_sentence);
			content+=" "+tagged_sentence.trim();
			
		    if(!tagged_sentence.contains("BAC00") || !tagged_sentence.contains("DIS00"))
		    	continue;
		    
			String regex = "(BAC|DIS)00\\S+";
			Pattern pat = Pattern.compile(regex); 
		    Matcher match = pat.matcher(tagged_sentence);

		    while(match.find())
		    {
		    	for(int i = 0 ; i < annotated_result.size()-1 ; i++)
		    	{
		    		String annotated_term = annotated_result.get(i)[0];
		    		String original_term = annotated_result.get(i)[1];
		    	}
		    	writeEntityList(literature, match.group(), annotated_result);
		    }
			try {
				sentence_writer.write(literature.getPMID()+"_"+count+"\t"
						+tagged_sentence.trim());
				sentence_writer.newLine();
				sentence_writer.flush();
				count++;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private void writeEntityList(Literature literature, String tagged_name, ArrayList<String[]> annotated_result)
	{
		
		String tName = tagged_name.substring(5).replace("_", " ");
		String id = null;
		for(Annotation anno : literature.getAnnotationList())
		{
			System.out.println(anno.name.replaceAll("[^A-Za-z0-9\\_\\-\\s]", "0")+", "+tName+":"+(tName.contains(anno.name.replaceAll("[^A-Za-z0-9\\_\\-\\s]", "0"))));
			if(tName.contains(anno.name.replaceAll("[^A-Za-z0-9\\_\\-\\s]", "0"))
					&& tagged_name.substring(0, 3).toLowerCase().equals(anno.type.substring(0,3).toLowerCase()))
			{
				id = anno.id;
				break;
			}
		}
		if(tagged_name.startsWith("BAC00"))
		{
			try {
				FileStream.getBacteriaListWriter().write(literature.getPMID()+"\t"+tagged_name+"\t"+id);
				FileStream.getBacteriaListWriter().newLine();
				FileStream.getBacteriaListWriter().flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(tagged_name.startsWith("DIS00"))
		{
			try {
				FileStream.getDiseaseListWriter().write(literature.getPMID()+"\t"+tagged_name+"\t"+id);
				FileStream.getDiseaseListWriter().newLine();
				FileStream.getDiseaseListWriter().flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	private ArrayList<String[]> getAnnotatedContent(Literature literature)
	{
		ArrayList<String[]> result = new ArrayList<String[]>();
		String content = literature.getContent()+" ";
		ArrayList<Annotation> annotation_list = literature.getAnnotationList();
		int title_len = literature.getTitle().length();
		
		Collections.reverse(annotation_list);
		for(Annotation anno : annotation_list)
		{
			if(anno == null)
				continue;
			if(anno.name.toLowerCase().equals("bacteria"))
				continue;
			int anno_start = Integer.parseInt(anno.getStart());
			int anno_end = Integer.parseInt(anno.getEnd());
			
			if(Integer.parseInt(anno.getStart()) < title_len)
				continue;
			String entity = getTagggedWord(anno.getName(), anno.getType());
			content = content.substring(0, anno_start-title_len-1) + entity 
					+ content.substring(anno_end-title_len-1);
			
			result.add(new String[]{anno.getName(), entity});
		} //tag annotate on abstracts
		result.add(new String[]{content, null});
		return result;
	}
	
	private String remove_(String sentence)
	{
		String[] splitted = sentence.split("\\s+");
		String newSentence = "";
		for(String word:splitted)
		{
			if(word.startsWith("BAC00") || word.startsWith("DIS00")) {}
			else
				word = word.replace("_", " ");
			newSentence += " "+word;
		}
		return newSentence;
	}
	
	private ArrayList<String> splitSentence(String paragraph)
	{
		ArrayList<String> sentenceList = new ArrayList<String>();
		
		BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);
		iterator.setText(paragraph);
		int start = iterator.first();
		String sentence="";
		for (int end = iterator.next();
			    end != BreakIterator.DONE;
			    start = end, end = iterator.next()) {
				sentence += paragraph.substring(start,end);
//				System.out.println(sentence.endsWith("sp."));
				if(sentence.trim().endsWith(" sp.") || sentence.trim().endsWith(" spp.")
						|| sentence.trim().endsWith(" subsp.") || sentence.trim().endsWith(" subspp.")
						|| sentence.trim().endsWith(" str.") || sentence.trim().endsWith(" substr.")){}
				else
				{
					sentenceList.add(sentence);
					sentence = "";
				}
		}
		if(sentence != "")
			sentenceList.add(sentence);
		return sentenceList;
	}
	
	private static String getTagggedWord(String word, String type)
	{
		type = type.substring(0, 3)+"00";
		type = type.toUpperCase();
		
		word = word.trim();
		word = word.replaceAll("\\s", "_");
		if(type.equals("DIS00") || type.equals("BAC00"))
			word = word.replaceAll("[^A-Za-z0-9\\_\\-]", "0");
		
		return type+word;
		
	}
}
