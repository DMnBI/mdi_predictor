package DBNER.Main;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

public class CommandParser {

	public String PROGRAM_NAME = "DBNER";
	public String USAGE = "java -jar " + PROGRAM_NAME + ".jar [OPTION]... [arg]...";

	private Options options;
	
	public CommandParser()
	{
		options = setOption();
	}
	
	public void parse(String[] args) throws ParseException {
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd = parser.parse(options, args);

		String configure_path = getOption(cmd, "c", true);
	}

	private String getOption(CommandLine cmd, String opt, boolean isRequirement) {
		HelpFormatter formatter = new HelpFormatter();

		if (cmd.hasOption(opt))
			return cmd.getOptionValue(opt);
		else if (isRequirement) {
			formatter.printHelp(USAGE, options);
			System.exit(0);
		}
		return "";
	}

	private Options setOption() {
		Options options = new Options();
		options.addOption("c", "config", true, "config file path");
		return options;
	}
}
