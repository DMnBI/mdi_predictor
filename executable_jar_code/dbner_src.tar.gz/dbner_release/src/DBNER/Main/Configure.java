package DBNER.Main;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Configure {
	
	public static String INPUT_FILE_PATH;
	public static String OUTPUT_FILE_PATH;
	public static String GRAPH_DIRECTORY_PATH;
	public static String BACTERIA_DICT_PATH;
	public static String STRAIN_DICT_PATH;
	public static String VIRUS_DICT_PATH;
	
	public Configure(String config_path)
	{
		Properties options = new Properties();
		InputStream input;
        
		try {
            input = new FileInputStream(config_path);
            options.load(input);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        this.INPUT_FILE_PATH = options.getProperty("INPUT_FILE_PATH");
        this.OUTPUT_FILE_PATH = options.getProperty("OUTPUT_FILE_PATH");
        this.GRAPH_DIRECTORY_PATH = options.getProperty("GRAPH_DIRECTORY_PATH");
        this.BACTERIA_DICT_PATH = options.getProperty("BACTERIA_DICT_PATH", "data/bacteria_list.txt");
        this.STRAIN_DICT_PATH = options.getProperty("STRAIN_DICT_PATH", "data/strain_list.txt");
        this.VIRUS_DICT_PATH = options.getProperty("VIRUS_DICT_PATH", "data/virus_list.txt");
	}
}
