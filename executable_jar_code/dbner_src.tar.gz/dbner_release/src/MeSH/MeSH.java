package MeSH;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MeSH {
	
	
	public String getID(String disease)
	{
		disease = encoding(disease);
		ArrayList<String> idList = new ArrayList<String>();
		String url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=mesh&term="+disease+"[mesh]";
		Document doc = getDocumentFromURL(url, 0);
		
		if(doc == null)
			return null;
		
		NodeList idNodeList = doc.getElementsByTagName("Id");
		for(int index = 0 ; index < idNodeList.getLength() ; index ++)
		{
			idList.add(idNodeList.item(index).getTextContent());
		}				
		return idList.get(idList.size()-1);		
	}
	public Document getDocumentFromURL(String url, int tryCount)
	{
		DocumentBuilderFactory dbFactoty = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		System.out.println(url);
		try {
			dBuilder = dbFactoty.newDocumentBuilder();
			Document doc = dBuilder.parse(url);
			if(doc == null)
				return null;
			
			doc.getDocumentElement().normalize();
			return doc;
		} catch (Exception e) {
			System.out.println(e);
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return getDocumentFromURL(url, tryCount+1);
		}
	}
	public String getMeSHTerm(String dName)
	{
		String url;
		
		dName = encoding(dName);
		url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=mesh&term="+dName+"[mesh]";
		
		try {
			Document doc = getDocumentFromURL(url, 0);
			
			Node translationNode = doc.getElementsByTagName("To").item(0);
			String term = translationNode.getTextContent();
			
			String meshTerm;
			
			if(term.contains("\\[MeSH Terms\\]"))
				term = term.split("\\[MeSH Terms\\]")[0];
			else
				term = term.split("\\[")[0];
			
			meshTerm = term.replace("\"", "");
			if(isDisease(meshTerm))
				return meshTerm;
			else
				return "";
		}catch(Exception e)
		{
			return "";
		}
		
	}
	public boolean isDisease(String meshTerm)
	{
		String id = getID(meshTerm); 
		String url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=mesh&id=%s&rettype=docsum&version=2.0";
		Document doc = getDocumentFromURL(String.format(url, id), 10);
		NodeList idxLinkList = doc.getElementsByTagName("DS_IdxLinks").item(0).getChildNodes();
		String treeNum;
		for(int i = 1 ; i < idxLinkList.getLength() ; i+=2)
		{
			treeNum = idxLinkList.item(i).getChildNodes().item(3).getTextContent();
			if(treeNum.startsWith("C"))
				return true;
		}
		return false;
	}
	public String encoding(String str)
	{
		return str.replace(" ", "%20");
	}
	
    private Document parseXML(InputStream stream) throws Exception{
    	 
        DocumentBuilderFactory objDocumentBuilderFactory = null;
        DocumentBuilder objDocumentBuilder = null;
        Document doc = null;
 
        try{ 
            objDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
            objDocumentBuilder = objDocumentBuilderFactory.newDocumentBuilder();
 
            doc = objDocumentBuilder.parse(stream);
 
        }catch(Exception ex){
            throw ex;
        }       
 
        return doc;
    }
}
